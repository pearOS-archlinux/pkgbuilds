<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../about.ui" line="14"/>
        <location filename="../../build/src/ui_about.h" line="140"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../about.ui" line="37"/>
        <location filename="../../build/src/ui_about.h" line="142"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:600;&quot;&gt;Filer&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:600;&quot;&gt;Filer&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="60"/>
        <location filename="../../build/src/ui_about.h" line="144"/>
        <source>The Desktop Experience</source>
        <translation>A Experiência de Desktop</translation>
    </message>
    <message>
        <location filename="../about.ui" line="70"/>
        <location filename="../../build/src/ui_about.h" line="145"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://github.com/helloSystem/Filer/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://github.com/helloSystem/Filer/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://github.com/helloSystem/Filer/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://github.com/helloSystem/Filer/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="99"/>
        <location filename="../../build/src/ui_about.h" line="146"/>
        <source>Programming:
* Simon Peter (probono)
* Chris Moore (moochris)
* Hong Jen Yee (PCMan) &lt;pcman.tw@gmail.com&gt;

Application icon:
* Raphael Lopes (https://raphaellopes.me/)</source>
        <translation>Programação:
* Simon Peter (probono)
* Chris Moore (moochris)
* Hong Jen Yee (PCMan) &lt;pcman.tw@gmail.com&gt;

Ícone do aplicativo:
* Raphael Lopes (https://raphaellopes.me/)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="125"/>
        <location filename="../../build/src/ui_about.h" line="154"/>
        <source>Filer

Copyright (C) 2020-21 Simon Peter
Copyright (C) 2021 Chris Moore

Originally based on PCMan File Manager
Portions Copyright (C) 2009-14 洪任諭 (Hong Jen Yee)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Application icon

https://dribbble.com/shots/2541211--Pirate-Finder-icon#

Copyright (C) 2016 Raphael Lopes &lt;raphaellopes8@gmail.com&gt;

Used with permission of the creator https://raphaellopes.me/</source>
        <translation>Filer

Copyright (C) 2020-21 Simon Peter
Copyright (C) 2021 Chris Moore

Baseado originalmente no PCMan File Manager
Partes do Copyright (C) 2009-14 洪任諭 (Hong Jen Yee)

Este programa é um software livre; você pode redistribuí-lo e/ou
modificá-lo sob os termos da Licença Pública Geral GNU, conforme
publicado pela Free Software Foundation, seja a versão 2 da Licença
ou (a seu critério) qualquer versão posterior.

Este programa é distribuído na esperança de que seja útil,
mas SEM QUALQUER GARANTIA; nem mesmo a garantia implícita de
COMERCIALIZAÇÃO OU ADEQUAÇÃO A UM DETERMINADO PROPÓSITO. Veja a
Licença Pública Geral GNU para obter mais detalhes.

Você deve ter recebido uma cópia da Licença Pública Geral GNU
junto com este programa. Se não, escreva para a Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Ícone do aplicativo

https://dribbble.com/shots/2541211--Pirate-Finder-icon#

Copyright (C) 2016 Raphael Lopes &lt;raphaellopes8@gmail.com&gt;

Usado com permissão do criador https://raphaellopes.me/</translation>
    </message>
    <message>
        <location filename="../about.ui" line="90"/>
        <location filename="../../build/src/ui_about.h" line="153"/>
        <source>Authors</source>
        <translation>Autores</translation>
    </message>
    <message>
        <location filename="../about.ui" line="116"/>
        <location filename="../../build/src/ui_about.h" line="184"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
</context>
<context>
    <name>AppChooserDialog</name>
    <message>
        <location filename="../app-chooser-dialog.ui" line="14"/>
        <location filename="../../build/src/ui_app-chooser-dialog.h" line="150"/>
        <source>Choose an Application</source>
        <translation>Escolha um Aplicativo</translation>
    </message>
    <message>
        <location filename="../app-chooser-dialog.ui" line="36"/>
        <location filename="../../build/src/ui_app-chooser-dialog.h" line="151"/>
        <source>Installed Applications</source>
        <translation>Aplicativos Instalados</translation>
    </message>
    <message>
        <location filename="../app-chooser-dialog.ui" line="46"/>
        <location filename="../../build/src/ui_app-chooser-dialog.h" line="163"/>
        <source>Custom Command</source>
        <translation>Comando Personalizado</translation>
    </message>
    <message>
        <location filename="../app-chooser-dialog.ui" line="52"/>
        <location filename="../../build/src/ui_app-chooser-dialog.h" line="152"/>
        <source>Command line to execute:</source>
        <translation>Linha de comando para executar:</translation>
    </message>
    <message>
        <location filename="../app-chooser-dialog.ui" line="62"/>
        <location filename="../../build/src/ui_app-chooser-dialog.h" line="153"/>
        <source>Application name:</source>
        <translation>Nome do aplicativo:</translation>
    </message>
    <message>
        <location filename="../app-chooser-dialog.ui" line="72"/>
        <location filename="../../build/src/ui_app-chooser-dialog.h" line="154"/>
        <source>&lt;b&gt;These special codes can be used in the command line:&lt;/b&gt;
&lt;ul&gt;
&lt;li&gt;&lt;b&gt;%f&lt;/b&gt;: Represents a single file name&lt;/li&gt;
&lt;li&gt;&lt;b&gt;%F&lt;/b&gt;: Represents multiple file names&lt;/li&gt;
&lt;li&gt;&lt;b&gt;%u&lt;/b&gt;: Represents a single URI of the file&lt;/li&gt;
&lt;li&gt;&lt;b&gt;%U&lt;/b&gt;: Represents multiple URIs&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>&lt;b&gt;Você pode utilizar os seguintes códigos na linha de comando:&lt;/b&gt;
&lt;ul&gt;
&lt;li&gt;&lt;b&gt;%f&lt;/b&gt;: é o nome de um arquivo&lt;/li&gt;
&lt;li&gt;&lt;b&gt;%F&lt;/b&gt;: é o nome de vários arquivos&lt;/li&gt;
&lt;li&gt;&lt;b&gt;%u&lt;/b&gt;: é o URI do arquivo&lt;/li&gt;
&lt;li&gt;&lt;b&gt;%U&lt;/b&gt;: é o URI de vários arquivos&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../app-chooser-dialog.ui" line="91"/>
        <location filename="../../build/src/ui_app-chooser-dialog.h" line="161"/>
        <source>Keep terminal window open after command execution</source>
        <translation>Manter janela de terminal aberta depois de executar o comando</translation>
    </message>
    <message>
        <location filename="../app-chooser-dialog.ui" line="98"/>
        <location filename="../../build/src/ui_app-chooser-dialog.h" line="162"/>
        <source>Execute in terminal emulator</source>
        <translation>Executar no emulador de terminal</translation>
    </message>
    <message>
        <location filename="../app-chooser-dialog.ui" line="109"/>
        <location filename="../../build/src/ui_app-chooser-dialog.h" line="164"/>
        <source>Set selected application as default action of this file type</source>
        <translation>Utilizar o aplicativo selecionado como padrão para este tipo de arquivo</translation>
    </message>
</context>
<context>
    <name>AppMenuModel</name>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="503"/>
        <source>New Finder Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="504"/>
        <source>New Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="507"/>
        <source>Undo	⌘Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="508"/>
        <source>Redo	⇧⌘Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="510"/>
        <source>Cut	⌘X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="511"/>
        <source>Copy	⌘C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="512"/>
        <source>Paste	⌘V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="513"/>
        <source>Select All	⌘A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="516"/>
        <source>Show Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="517"/>
        <source>Show Sidebar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="518"/>
        <source>Show Hidden Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="520"/>
        <source>Zoom In	⌘+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="521"/>
        <source>Zoom Out	⌘-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="522"/>
        <source>Actual Size	⌘0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="524"/>
        <source>Refresh	⌘R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="527"/>
        <source>Back	⌘[</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="528"/>
        <source>Forward	⌘]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="530"/>
        <source>Recents	⇧⌘F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="531"/>
        <source>Documents	⇧⌘O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="532"/>
        <source>Desktop	⇧⌘D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="533"/>
        <source>Downloads	⌥⌘L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="534"/>
        <source>Home	⇧⌘H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="535"/>
        <source>Computer	⇧⌘C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="536"/>
        <source>Applications	⇧⌘A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="538"/>
        <source>Recent Folders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="541"/>
        <source>No recent folders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="552"/>
        <source>Go to Folder…	⇧⌘G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="560"/>
        <source>Minimize	⌘M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="562"/>
        <source>Zoom	⌥⌘Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="570"/>
        <source>Close Window	⌘W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="572"/>
        <source>Bring All to Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="575"/>
        <source>Donate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="576"/>
        <source>Join pearOS Discord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="577"/>
        <source>Get NordVPN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="578"/>
        <source>Get NordPass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="579"/>
        <source>Join Reddit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="580"/>
        <source>YouTube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="581"/>
        <source>Instagram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="582"/>
        <source>pearOS Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="583"/>
        <source>pearID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/backends/appmenu/appmenumodel.cpp" line="584"/>
        <source>GitHub</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutoRunDialog</name>
    <message>
        <location filename="../autorun.ui" line="14"/>
        <location filename="../../build/src/ui_autorun.h" line="108"/>
        <source>Removable medium is inserted</source>
        <translation>Disco removível inserido</translation>
    </message>
    <message>
        <location filename="../autorun.ui" line="33"/>
        <location filename="../../build/src/ui_autorun.h" line="110"/>
        <source>&lt;b&gt;Removable medium is inserted&lt;/b&gt;</source>
        <translation>&lt;b&gt;Disco removível inserido&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../autorun.ui" line="40"/>
        <location filename="../../build/src/ui_autorun.h" line="111"/>
        <source>Type of medium:</source>
        <translation>Tipo de dispositivo:</translation>
    </message>
    <message>
        <location filename="../autorun.ui" line="47"/>
        <location filename="../../build/src/ui_autorun.h" line="112"/>
        <source>Detecting...</source>
        <translation>Detectando...</translation>
    </message>
    <message>
        <location filename="../autorun.ui" line="56"/>
        <location filename="../../build/src/ui_autorun.h" line="113"/>
        <source>Please select the action you want to perform:</source>
        <translation>Por favor, selecione a ação que deseja realizar:</translation>
    </message>
</context>
<context>
    <name>BlurEffectConfig</name>
    <message>
        <location filename="../../kwin/src/plugins/blur/blur_config.ui" line="17"/>
        <source>Blur strength:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/blur/blur_config.ui" line="53"/>
        <location filename="../../kwin/src/plugins/blur/blur_config.ui" line="107"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/blur/blur_config.ui" line="60"/>
        <location filename="../../kwin/src/plugins/blur/blur_config.ui" line="114"/>
        <location filename="../../kwin/src/plugins/blur/blur_config.ui" line="168"/>
        <source>Strong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/blur/blur_config.ui" line="74"/>
        <source>Noise strength:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/blur/blur_config.ui" line="128"/>
        <source>Saturation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/blur/blur_config.ui" line="161"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DebugConsole</name>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="14"/>
        <source>Debug Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="30"/>
        <source>Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="43"/>
        <source>Pick Window…</source>
        <comment>@action:button</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="54"/>
        <source>Input Events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="71"/>
        <source>Input Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="81"/>
        <source>OpenGL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="87"/>
        <source>No OpenGL compositor running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="115"/>
        <source>OpenGL (ES) driver information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="121"/>
        <source>Vendor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="128"/>
        <source>Renderer:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="135"/>
        <source>Version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="142"/>
        <source>Shading Language Version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="149"/>
        <source>Driver:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="156"/>
        <source>GPU class:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="163"/>
        <source>OpenGL Version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="170"/>
        <source>GLSL Version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="236"/>
        <source>Platform Extensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="252"/>
        <source>OpenGL (ES) Extensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="273"/>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="300"/>
        <source>Keymap Layouts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="322"/>
        <source>Current Layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="341"/>
        <source>Modifiers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="357"/>
        <source>Active Modifiers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="373"/>
        <source>LEDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="389"/>
        <source>Active LEDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="410"/>
        <location filename="../../kwin/src/debug_console.ui" line="430"/>
        <source>Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/debug_console.ui" line="476"/>
        <source>Primary Selection</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DesktopFolder</name>
    <message>
        <location filename="../desktop-folder.ui" line="14"/>
        <location filename="../../build/src/ui_desktop-folder.h" line="72"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../desktop-folder.ui" line="23"/>
        <location filename="../../build/src/ui_desktop-folder.h" line="73"/>
        <source>Desktop</source>
        <translation>Área de trabalho</translation>
    </message>
    <message>
        <location filename="../desktop-folder.ui" line="29"/>
        <location filename="../../build/src/ui_desktop-folder.h" line="74"/>
        <source>Desktop folder:</source>
        <translation>Pasta da área de trabalho:</translation>
    </message>
    <message>
        <location filename="../desktop-folder.ui" line="36"/>
        <location filename="../../build/src/ui_desktop-folder.h" line="76"/>
        <source>Image file</source>
        <translation>Arquivo de imagem</translation>
    </message>
    <message>
        <location filename="../desktop-folder.ui" line="42"/>
        <location filename="../../build/src/ui_desktop-folder.h" line="81"/>
        <source>Folder path</source>
        <translation>Caminho da pasta</translation>
    </message>
    <message>
        <location filename="../desktop-folder.ui" line="49"/>
        <location filename="../../build/src/ui_desktop-folder.h" line="82"/>
        <source>&amp;Browse</source>
        <translation>E&amp;xplorar</translation>
    </message>
</context>
<context>
    <name>DesktopPreferencesDialog</name>
    <message>
        <location filename="../desktop-preferences.ui" line="14"/>
        <location filename="../../build/src/ui_desktop-preferences.h" line="175"/>
        <source>Desktop Preferences</source>
        <translation>Preferências da Área de Trabalho</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="vanished">Fundo</translation>
    </message>
    <message>
        <source>Wallpaper mode:</source>
        <translation type="vanished">Modo do papel de parede:</translation>
    </message>
    <message>
        <source>Wallpaper image file:</source>
        <translation type="vanished">Arquivo do papel de parede:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="79"/>
        <location filename="../../build/src/ui_desktop-preferences.h" line="186"/>
        <source>Colors</source>
        <translation>Cores</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="137"/>
        <location filename="../../build/src/ui_desktop-preferences.h" line="191"/>
        <source>Background color:</source>
        <translation>Cor de fundo:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="91"/>
        <location filename="../../build/src/ui_desktop-preferences.h" line="187"/>
        <source>Text color:</source>
        <translation>Cor do texto:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="20"/>
        <location filename="../../build/src/ui_desktop-preferences.h" line="176"/>
        <source>Desktop Picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="37"/>
        <location filename="../../build/src/ui_desktop-preferences.h" line="183"/>
        <source>Picture file path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="69"/>
        <location filename="../../build/src/ui_desktop-preferences.h" line="185"/>
        <source>Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="130"/>
        <location filename="../../build/src/ui_desktop-preferences.h" line="190"/>
        <source>Shadow color:</source>
        <translation>Cor da sombra:</translation>
    </message>
    <message>
        <source>Font:</source>
        <translation type="vanished">Fonte:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="31"/>
        <location filename="../../build/src/ui_desktop-preferences.h" line="178"/>
        <source>Image file</source>
        <translation>Arquivo da imagem</translation>
    </message>
    <message>
        <source>Image file path</source>
        <translation type="vanished">Caminho do arquivo da imagem</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="44"/>
        <location filename="../../build/src/ui_desktop-preferences.h" line="184"/>
        <source>&amp;Browse</source>
        <translation>E&amp;xplorar</translation>
    </message>
    <message>
        <source>Label Text</source>
        <translation type="vanished">Texto</translation>
    </message>
</context>
<context>
    <name>DimInactiveEffectConfig</name>
    <message>
        <location filename="../../kwin/src/plugins/diminactive/diminactive_config.ui" line="17"/>
        <source>Strength:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/diminactive/diminactive_config.ui" line="43"/>
        <source>Dim:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/diminactive/diminactive_config.ui" line="50"/>
        <source>Docks and panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/diminactive/diminactive_config.ui" line="57"/>
        <source>Desktop</source>
        <translation type="unfinished">Área de trabalho</translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/diminactive/diminactive_config.ui" line="64"/>
        <source>Keep above windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/diminactive/diminactive_config.ui" line="71"/>
        <source>By window group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/diminactive/diminactive_config.ui" line="78"/>
        <source>Fullscreen windows</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditBookmarksDialog</name>
    <message>
        <location filename="../edit-bookmarks.ui" line="14"/>
        <location filename="../../build/src/ui_edit-bookmarks.h" line="103"/>
        <source>Edit Bookmarks</source>
        <translation>Editar Favoritos</translation>
    </message>
    <message>
        <location filename="../edit-bookmarks.ui" line="42"/>
        <location filename="../../build/src/ui_edit-bookmarks.h" line="106"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../edit-bookmarks.ui" line="47"/>
        <location filename="../../build/src/ui_edit-bookmarks.h" line="105"/>
        <source>Location</source>
        <translation>Localização</translation>
    </message>
    <message>
        <location filename="../edit-bookmarks.ui" line="67"/>
        <location filename="../../build/src/ui_edit-bookmarks.h" line="107"/>
        <source>&amp;Add Item</source>
        <translation>&amp;Adicionar item</translation>
    </message>
    <message>
        <location filename="../edit-bookmarks.ui" line="77"/>
        <location filename="../../build/src/ui_edit-bookmarks.h" line="108"/>
        <source>&amp;Remove Item</source>
        <translation>&amp;Remover item</translation>
    </message>
    <message>
        <location filename="../edit-bookmarks.ui" line="102"/>
        <location filename="../../build/src/ui_edit-bookmarks.h" line="109"/>
        <source>Use drag and drop to reorder the items</source>
        <translation>Arraste e solte para organizar os itens</translation>
    </message>
</context>
<context>
    <name>ExecFileDialog</name>
    <message>
        <location filename="../exec-file.ui" line="14"/>
        <location filename="../../build/src/ui_exec-file.h" line="114"/>
        <source>Execute file</source>
        <translation>Executar arquivo</translation>
    </message>
    <message>
        <location filename="../exec-file.ui" line="39"/>
        <location filename="../../build/src/ui_exec-file.h" line="116"/>
        <source>&amp;Open</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <location filename="../exec-file.ui" line="52"/>
        <location filename="../../build/src/ui_exec-file.h" line="117"/>
        <source>E&amp;xecute</source>
        <translation>E&amp;xecutar</translation>
    </message>
    <message>
        <location filename="../exec-file.ui" line="62"/>
        <location filename="../../build/src/ui_exec-file.h" line="118"/>
        <source>Execute in &amp;Terminal</source>
        <translation>Executar no &amp;Terminal</translation>
    </message>
    <message>
        <location filename="../exec-file.ui" line="85"/>
        <location filename="../../build/src/ui_exec-file.h" line="119"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>FadeDesktopConfig</name>
    <message>
        <location filename="../../kwin/src/plugins/fadedesktop/package/contents/ui/config.ui" line="17"/>
        <source>Animation duration:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileOperationDialog</name>
    <message>
        <location filename="../file-operation-dialog.ui" line="25"/>
        <location filename="../../build/src/ui_file-operation-dialog.h" line="124"/>
        <source>Destination:</source>
        <translation>Destino:</translation>
    </message>
    <message>
        <location filename="../file-operation-dialog.ui" line="48"/>
        <location filename="../../build/src/ui_file-operation-dialog.h" line="126"/>
        <source>Processing:</source>
        <translation>Processamento:</translation>
    </message>
    <message>
        <location filename="../file-operation-dialog.ui" line="61"/>
        <location filename="../../build/src/ui_file-operation-dialog.h" line="127"/>
        <source>Preparing...</source>
        <translation>Preparando...</translation>
    </message>
    <message>
        <location filename="../file-operation-dialog.ui" line="68"/>
        <location filename="../../build/src/ui_file-operation-dialog.h" line="128"/>
        <source>Progress</source>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../file-operation-dialog.ui" line="88"/>
        <location filename="../../build/src/ui_file-operation-dialog.h" line="129"/>
        <source>Time remaining:</source>
        <translation>Tempo restante:</translation>
    </message>
</context>
<context>
    <name>FilePropsDialog</name>
    <message>
        <location filename="../file-props.ui" line="133"/>
        <location filename="../../build/src/ui_file-props.h" line="365"/>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="208"/>
        <location filename="../../build/src/ui_file-props.h" line="372"/>
        <source>Location:</source>
        <translation>Localização:</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="139"/>
        <location filename="../../build/src/ui_file-props.h" line="366"/>
        <source>File type:</source>
        <translation>Tipo de arquivo:</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="317"/>
        <location filename="../../build/src/ui_file-props.h" line="380"/>
        <source>Open with</source>
        <translation>Abrir com</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="323"/>
        <location filename="../../build/src/ui_file-props.h" line="381"/>
        <source>Mime type:</source>
        <translation>Tipo Mime:</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="162"/>
        <location filename="../../build/src/ui_file-props.h" line="368"/>
        <source>File size:</source>
        <translation>Tamanho do arquivo:</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="20"/>
        <location filename="../../build/src/ui_file-props.h" line="362"/>
        <source>Info</source>
        <translation>Informações</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="60"/>
        <location filename="../../build/src/ui_file-props.h" line="363"/>
        <source>TextLabel</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="185"/>
        <location filename="../../build/src/ui_file-props.h" line="370"/>
        <source>On-disk size:</source>
        <translation>Tamanho no disco:</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="260"/>
        <location filename="../../build/src/ui_file-props.h" line="376"/>
        <source>Last modified:</source>
        <translation>Última modificação:</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="423"/>
        <location filename="../../build/src/ui_file-props.h" line="385"/>
        <source>Everyone</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="234"/>
        <location filename="../../build/src/ui_file-props.h" line="374"/>
        <source>Link target:</source>
        <translation>Destino do link:</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="346"/>
        <location filename="../../build/src/ui_file-props.h" line="383"/>
        <source>Open With:</source>
        <translation>Abrir com:</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="283"/>
        <location filename="../../build/src/ui_file-props.h" line="378"/>
        <source>Last accessed:</source>
        <translation>Último acesso:</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="380"/>
        <location filename="../../build/src/ui_file-props.h" line="384"/>
        <source>Access Control</source>
        <translation>Controle de acesso</translation>
    </message>
    <message>
        <location filename="../file-props.ui" line="440"/>
        <location filename="../../build/src/ui_file-props.h" line="386"/>
        <source>Make the file executable</source>
        <translation>Marcar como executável</translation>
    </message>
</context>
<context>
    <name>Filer::Application</name>
    <message>
        <source>%1 was not launched by the launch command
from an application bundle.

This is not how it should be invoked.
Functionality may be broken.</source>
        <translation type="vanished">%1 não foi iniciado pelo comando launch
de um pacote de aplicativos.

Não é assim que deve ser chamado.

A funcionalidade pode estar quebrada.</translation>
    </message>
    <message>
        <source>The &apos;launch&apos; command is missing.</source>
        <translation type="vanished">Falta o comando &apos;launch&apos;.</translation>
    </message>
    <message>
        <source>The &apos;open&apos; command is missing.</source>
        <translation type="vanished">Falta o comando &apos;open&apos;.</translation>
    </message>
    <message>
        <source>The &apos;eject-and-clean&apos; command is missing.</source>
        <translation type="vanished">Falta o comando &apos;eject-and-clean&apos;.</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="524"/>
        <source>Name of configuration profile</source>
        <translation>Nome do perfil</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="524"/>
        <source>PROFILE</source>
        <translation>PERFIL</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="527"/>
        <source>Run Filer as a daemon</source>
        <translation>Executar Filer como serviço</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="530"/>
        <source>Quit Filer</source>
        <translation>Fechar Filer</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="533"/>
        <source>Launch desktop manager (deprecated)</source>
        <translation>Iniciar gerenciador da área de trabalho (obsoleto)</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="536"/>
        <source>Turn off desktop manager if it&apos;s running</source>
        <translation>Fechar gerenciador da área de trabalho se estiver em execução</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="539"/>
        <source>Open desktop preference dialog on the page with the specified name</source>
        <translation>Abrir diálogo de preferências da área de trabalho na página especificada</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="539"/>
        <location filename="../application.cpp" line="555"/>
        <source>NAME</source>
        <translation>NOME</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="542"/>
        <source>Open new window</source>
        <translation>Abrir nova janela</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="545"/>
        <source>Open Find Files utility</source>
        <translation>Abrir o utilitário Procurar Arquivos</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="548"/>
        <source>Set desktop wallpaper from image FILE</source>
        <translation>Definir papel de parede a partir de um arquivo</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="548"/>
        <source>FILE</source>
        <translation>ARQUIVO</translation>
    </message>
    <message>
        <source>Set mode of desktop wallpaper. MODE=(color|stretch|fit|center|tile)</source>
        <translation type="vanished">Definir modo do papel de parede. MODO=(color|stretch|fit|center|tile)</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="552"/>
        <source>MODE</source>
        <translation>MODO</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="552"/>
        <source>Set mode of desktop wallpaper. MODE=(none|transparent|stretch|fit|center|tile)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../application.cpp" line="555"/>
        <source>Open Preferences dialog on the page with the specified name</source>
        <translation>Abrir diálogo de preferências na página especificada</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="558"/>
        <source>Files or directories to open</source>
        <translation>Arquivos ou pastas para abrir</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="558"/>
        <source>[FILE1, FILE2,...]</source>
        <translation>[ARQUIVO1, ARQUIVO2,...]</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="1155"/>
        <location filename="../application.cpp" line="1162"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="1162"/>
        <source>Terminal emulator is not set.</source>
        <translation>O emulador de terminal não está definido.</translation>
    </message>
</context>
<context>
    <name>Filer::AutoRunDialog</name>
    <message>
        <location filename="../autorundialog.cpp" line="43"/>
        <source>Open in file manager</source>
        <translation>Abrir no gerenciador de arquivos</translation>
    </message>
    <message>
        <location filename="../autorundialog.cpp" line="133"/>
        <source>Removable Disk</source>
        <translation>Disco Removível</translation>
    </message>
</context>
<context>
    <name>Filer::DesktopItemDelegate</name>
    <message>
        <location filename="../desktopitemdelegate.cpp" line="380"/>
        <source>-- items</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Filer::DesktopPreferencesDialog</name>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="49"/>
        <source>Fill with background color only</source>
        <translation>Preencher apenas com a cor de fundo</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="50"/>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="51"/>
        <source>Stretch to fill the entire screen</source>
        <translation>Esticar para preencher a tela</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="52"/>
        <source>Stretch to fit the screen</source>
        <translation>Esticar para ajustar à tela</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="53"/>
        <source>Center on the screen</source>
        <translation>Centralizar na tela</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="54"/>
        <source>Tile the image to fill the entire screen</source>
        <translation>Imagens em mosaico para preencher a tela</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="140"/>
        <source>Image Files</source>
        <translation>Arquivos de Imagem</translation>
    </message>
</context>
<context>
    <name>Filer::DesktopWindow</name>
    <message>
        <location filename="../desktopwindow.cpp" line="699"/>
        <source>Stic&amp;k to Current Position</source>
        <translation>Fi&amp;xar na Posição Atual</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="731"/>
        <source>New Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="734"/>
        <source>Get Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="740"/>
        <source>Change Desktop Background...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="745"/>
        <source>Use Stacks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="750"/>
        <source>Sort By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="759"/>
        <source>Clean Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="762"/>
        <source>Clean Up By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="768"/>
        <source>Show View Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="783"/>
        <source>Name</source>
        <translation type="unfinished">Nome</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="784"/>
        <source>Kind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="785"/>
        <source>Date Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="786"/>
        <source>Date Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="787"/>
        <source>Size</source>
        <translation type="unfinished">Tamanho</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="788"/>
        <source>Tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="805"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="813"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desktop Preferences</source>
        <translation type="vanished">Preferências da Área de Trabalho</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="894"/>
        <source>Version: %1</source>
        <translation>Versão: %1</translation>
    </message>
</context>
<context>
    <name>Filer::GotoFolderDialog</name>
    <message>
        <location filename="../gotofolderwindow.cpp" line="47"/>
        <source>Go</source>
        <translation>Ir</translation>
    </message>
    <message>
        <location filename="../gotofolderwindow.cpp" line="48"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../gotofolderwindow.cpp" line="59"/>
        <source>Go To Folder</source>
        <translation>Ir à Pasta</translation>
    </message>
</context>
<context>
    <name>Filer::MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="648"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="824"/>
        <source>Column View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="832"/>
        <source>Gallery View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="844"/>
        <location filename="../mainwindow.cpp" line="891"/>
        <source>Show items as icons, in a list, in columns or in a gallery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1007"/>
        <source>Share</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="967"/>
        <location filename="../mainwindow.cpp" line="1019"/>
        <source>Tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="946"/>
        <source>Group By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="947"/>
        <location filename="../mainwindow.cpp" line="969"/>
        <source>Change the icon grouping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="957"/>
        <location filename="../mainwindow.cpp" line="1041"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="959"/>
        <source>Name</source>
        <translation type="unfinished">Nome</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="960"/>
        <source>Kind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="961"/>
        <source>Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="962"/>
        <source>Date Last Opened</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="963"/>
        <source>Date Added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="964"/>
        <source>Date Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="965"/>
        <source>Date Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="966"/>
        <source>Size</source>
        <translation type="unfinished">Tamanho</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1059"/>
        <source>More</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1398"/>
        <source>Clear text (Ctrl+K)</source>
        <translation>Limpar texto (Ctrl+K)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2224"/>
        <source>Version: %1</source>
        <translation>Versão: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2460"/>
        <source>Recents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2464"/>
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4043"/>
        <location filename="../mainwindow.cpp" line="4054"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4055"/>
        <source>Switch user command is not set.</source>
        <translation>O comando para trocar de usuário não está definido.</translation>
    </message>
</context>
<context>
    <name>Filer::OpenDialog</name>
    <message>
        <source>Icons</source>
        <translation type="obsolete">Ícones</translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="160"/>
        <location filename="../opendialog.cpp" line="315"/>
        <source>Open</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="233"/>
        <source>Show Sidebar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="173"/>
        <source>as Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="174"/>
        <source>as List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="175"/>
        <source>as Columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="196"/>
        <source>Show items as icons, in a list, or in columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="202"/>
        <source>Group By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="242"/>
        <source>Quick Jump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="261"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="301"/>
        <source>Save As:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="311"/>
        <source>Cancel</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="315"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="454"/>
        <source>Downloads</source>
        <translation type="unfinished">Downloads</translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="455"/>
        <source>Home</source>
        <translation type="unfinished">Pasta pessoal</translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="456"/>
        <source>Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="460"/>
        <source>Macintosh HD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="463"/>
        <source>Recent Places</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../opendialog.cpp" line="465"/>
        <source>No Recent Places</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Filer::PreferencesDialog</name>
    <message>
        <location filename="../preferencesdialog.cpp" line="190"/>
        <source>Icon View</source>
        <translation>Visão de Ícones</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="191"/>
        <source>Compact Icon View</source>
        <translation>Visão Compacta de Ícones</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="192"/>
        <source>Thumbnail View</source>
        <translation>Visão de Miniaturas</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="193"/>
        <source>Detailed List View</source>
        <translation>Visão de Lista Detalhada</translation>
    </message>
</context>
<context>
    <name>Filer::TabPage</name>
    <message>
        <location filename="../tabpage.cpp" line="288"/>
        <source>Size: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabpage.cpp" line="290"/>
        <source>Modified: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabpage.cpp" line="437"/>
        <location filename="../tabpage.cpp" line="608"/>
        <location filename="../tabpage.cpp" line="639"/>
        <source>Recents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabpage.cpp" line="521"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../tabpage.cpp" line="541"/>
        <source>%1 available</source>
        <translation>%1 disponível</translation>
    </message>
    <message numerus="yes">
        <location filename="../tabpage.cpp" line="554"/>
        <source>%n items</source>
        <translation>
            <numerusform>%n item</numerusform>
            <numerusform>%n itens</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../tabpage.cpp" line="556"/>
        <source>1 item</source>
        <translation>1 item</translation>
    </message>
    <message numerus="yes">
        <location filename="../tabpage.cpp" line="717"/>
        <source>%1 items selected</source>
        <translation>
            <numerusform>%1 item selecionado</numerusform>
            <numerusform>%1 itens selecionados</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../tabpage.cpp" line="721"/>
        <source>%1 item selected</source>
        <translation>
            <numerusform>%1 item selecionado</numerusform>
            <numerusform>%1 itens selecionados</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n item(s)</source>
        <translation type="vanished">
            <numerusform>%n item</numerusform>
            <numerusform>%n itens</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source> (%n hidden)</source>
        <translation type="vanished">
            <numerusform> (%n oculto)</numerusform>
            <numerusform> (%n ocultos)</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%1 item(s) selected</source>
        <translation type="vanished">
            <numerusform>%1 item selecionado</numerusform>
            <numerusform>%1 itens selecionados</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>Filer::View</name>
    <message>
        <location filename="../view.cpp" line="119"/>
        <source>Open in New Win&amp;dow</source>
        <translation>Abrir em &amp;Nova Janela</translation>
    </message>
    <message>
        <location filename="../view.cpp" line="127"/>
        <source>Open in Termina&amp;l</source>
        <translation>Abrir no Termina&amp;l</translation>
    </message>
</context>
<context>
    <name>Filer::ViewOptionsPopup</name>
    <message>
        <location filename="../viewoptionspopup.cpp" line="31"/>
        <source>Sort By:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Nome</translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="16"/>
        <source>View Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="23"/>
        <source>Stack By:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="25"/>
        <location filename="../viewoptionspopup.cpp" line="33"/>
        <source>Kind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="25"/>
        <location filename="../viewoptionspopup.cpp" line="33"/>
        <source>Date Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="25"/>
        <location filename="../viewoptionspopup.cpp" line="33"/>
        <source>Date Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="25"/>
        <location filename="../viewoptionspopup.cpp" line="33"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="25"/>
        <location filename="../viewoptionspopup.cpp" line="33"/>
        <source>Date Last Opened</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="25"/>
        <location filename="../viewoptionspopup.cpp" line="33"/>
        <source>Date Added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="33"/>
        <source>Snap To Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="39"/>
        <source>Icon size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="48"/>
        <source>Grid spacing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="57"/>
        <source>Text size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="64"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="70"/>
        <source>Label position:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="71"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="72"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="82"/>
        <source>Show item info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="84"/>
        <source>Show icon preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Tamanho</translation>
    </message>
    <message>
        <location filename="../viewoptionspopup.cpp" line="25"/>
        <location filename="../viewoptionspopup.cpp" line="33"/>
        <source>Tags</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FindFilesDialog</name>
    <message>
        <location filename="../file-search.ui" line="14"/>
        <source>Find Files</source>
        <translation>Buscar arquivos</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="24"/>
        <source>Name/Location</source>
        <translation>Nome/Posição</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="30"/>
        <source>File name patterns</source>
        <translation>Padrões de nome de arquivos</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="36"/>
        <source>Pattern:</source>
        <translation>Padrão:</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="46"/>
        <location filename="../file-search.ui" line="221"/>
        <source>Case insensitive</source>
        <translation>Ignorar maiúsculas</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="53"/>
        <location filename="../file-search.ui" line="228"/>
        <source>Use regular expression</source>
        <translation>Usar expressão regular</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="63"/>
        <source>Places to search</source>
        <translation>Lugares para procurar</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="76"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="88"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="117"/>
        <source>Search in sub directories</source>
        <translation>Procurar em subpastas</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="124"/>
        <source>Search hidden files</source>
        <translation>Procurar arquivos ocultos</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="135"/>
        <location filename="../file-search.ui" line="141"/>
        <source>File Type</source>
        <translation>Tipo de Arquivo</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="147"/>
        <source>Only search for files of following types:</source>
        <translation>Buscar somente os seguintes tipos de arquivo:</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="154"/>
        <source>Text files</source>
        <translation>Arquivos de texto</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="161"/>
        <source>Image files</source>
        <translation>Arquivos de imagens</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="168"/>
        <source>Audio files</source>
        <translation>Arquivos de áudio</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="175"/>
        <source>Video files</source>
        <translation>Arquivos de vídeo</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="182"/>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="206"/>
        <source>Content</source>
        <translation>Conteúdo</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="212"/>
        <source>File contains</source>
        <translation>Conteúdo do arquivo</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="252"/>
        <source>Info</source>
        <translation>Informações</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="258"/>
        <source>File Size</source>
        <translation>Tamanho do Arquivo</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="264"/>
        <source>Bigger than:</source>
        <translation>Maior que:</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="289"/>
        <source>Smaller than:</source>
        <translation>Menor que:</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="317"/>
        <source>Last Modified Time</source>
        <translation>Data da Última Modificação</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="323"/>
        <source>Earlier than:</source>
        <translation>Antes de:</translation>
    </message>
    <message>
        <location filename="../file-search.ui" line="340"/>
        <source>Later than:</source>
        <translation>Depois de:</translation>
    </message>
</context>
<context>
    <name>Fm::AppChooserComboBox</name>
    <message>
        <location filename="../appchoosercombobox.cpp" line="79"/>
        <source>Customize</source>
        <translation>Personalizar</translation>
    </message>
</context>
<context>
    <name>Fm::AppChooserDialog</name>
    <message>
        <location filename="../appchooserdialog.cpp" line="262"/>
        <source>Select an application to open &quot;%1&quot; files</source>
        <translation>Selecione um aplicativo para abrir os arquivos &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>Fm::ColumnView</name>
    <message>
        <location filename="../columnview.cpp" line="114"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columnview.cpp" line="187"/>
        <source>Created: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columnview.cpp" line="188"/>
        <source>Modified: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columnview.cpp" line="192"/>
        <source>Tags: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columnview.cpp" line="192"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Fm::CreateNewMenu</name>
    <message>
        <location filename="../createnewmenu.cpp" line="29"/>
        <source>Folder</source>
        <translation>Pasta</translation>
    </message>
    <message>
        <location filename="../createnewmenu.cpp" line="33"/>
        <source>Blank File</source>
        <translation>Arquivo Vazio</translation>
    </message>
</context>
<context>
    <name>Fm::DirTreeModel</name>
    <message>
        <location filename="../dirtreemodelitem.cpp" line="77"/>
        <source>Loading...</source>
        <translation>Carregando...</translation>
    </message>
    <message>
        <location filename="../dirtreemodelitem.cpp" line="208"/>
        <source>&lt;No sub folders&gt;</source>
        <translation>&lt;Não existem subpastas&gt;</translation>
    </message>
</context>
<context>
    <name>Fm::DirTreeView</name>
    <message>
        <location filename="../dirtreeview.cpp" line="220"/>
        <source>Open in New Win&amp;dow</source>
        <translation>Abrir em Nova &amp;Janela</translation>
    </message>
    <message>
        <location filename="../dirtreeview.cpp" line="226"/>
        <source>Open in Termina&amp;l</source>
        <translation>Abrir no Termina&amp;l</translation>
    </message>
</context>
<context>
    <name>Fm::DndActionMenu</name>
    <message>
        <location filename="../dndactionmenu.cpp" line="26"/>
        <source>Copy here</source>
        <translation>Copiar aqui</translation>
    </message>
    <message>
        <location filename="../dndactionmenu.cpp" line="27"/>
        <source>Move here</source>
        <translation>Mover aqui</translation>
    </message>
    <message>
        <location filename="../dndactionmenu.cpp" line="28"/>
        <source>Create symlink here</source>
        <translation>Criar link simbólico aqui</translation>
    </message>
    <message>
        <location filename="../dndactionmenu.cpp" line="30"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>Fm::EditBookmarksDialog</name>
    <message>
        <location filename="../editbookmarksdialog.cpp" line="96"/>
        <source>New bookmark</source>
        <translation>Novo favorito</translation>
    </message>
</context>
<context>
    <name>Fm::ExecFileDialog</name>
    <message>
        <location filename="../execfiledialog.cpp" line="40"/>
        <source>This text file &apos;%1&apos; seems to be an executable script.
What do you want to do with it?</source>
        <translation>Parece que o arquivo de texto &quot;%1&quot; é um script executável.
O que você deseja fazer com ele?</translation>
    </message>
    <message>
        <location filename="../execfiledialog.cpp" line="45"/>
        <source>This file &apos;%1&apos; is executable. Do you want to execute it?</source>
        <translation>O arquivo %1 é um executável. Deseja executá-lo?</translation>
    </message>
</context>
<context>
    <name>Fm::FileMenu</name>
    <message>
        <location filename="../filemenu.cpp" line="118"/>
        <location filename="../filemenu.cpp" line="562"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="123"/>
        <source>Open With...</source>
        <translation>Abrir com...</translation>
    </message>
    <message>
        <source>Other Applications</source>
        <translation type="vanished">Outros Aplicativos</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="208"/>
        <source>Create &amp;New</source>
        <translation>Criar &amp;Novo</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation type="vanished">&amp;Restaurar</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="130"/>
        <source>Show Contents</source>
        <translation>Mostrar Conteúdo</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="137"/>
        <location filename="../filemenu.cpp" line="687"/>
        <source>Tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="149"/>
        <location filename="../filemenu.cpp" line="698"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="215"/>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="219"/>
        <location filename="../filemenu.cpp" line="641"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="223"/>
        <source>Paste</source>
        <translation>Colar</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="228"/>
        <source>&amp;Move to Trash</source>
        <translation>&amp;Move para a Lixeira</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="232"/>
        <location filename="../filemenu.cpp" line="619"/>
        <source>Rename</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="280"/>
        <location filename="../filemenu.cpp" line="615"/>
        <source>Get Info</source>
        <translation>Obter Informações</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="285"/>
        <source>&amp;Empty Trash</source>
        <translation>&amp;Esvaziar Lixeira</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="411"/>
        <source>Output</source>
        <translation>Saída</translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="558"/>
        <source>Open in New Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="567"/>
        <source>Show Package Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="572"/>
        <source>Open With</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="586"/>
        <source>Other...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="600"/>
        <source>Eject &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="608"/>
        <source>Move to Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="623"/>
        <source>Compress &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="627"/>
        <source>Duplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="631"/>
        <source>Make Alias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="635"/>
        <source>Quick Look</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="645"/>
        <source>Share...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="676"/>
        <source>Customize Folder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="682"/>
        <source>Import from Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="683"/>
        <location filename="../filemenu.cpp" line="708"/>
        <location filename="../filemenu.cpp" line="809"/>
        <source>Not implemented yet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="707"/>
        <source>Quick Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="714"/>
        <source>Folder Actions Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="718"/>
        <source>New Terminal at Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="722"/>
        <source>New Terminal Tab at Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="729"/>
        <source>Set Desktop Picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="753"/>
        <source>Compress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="754"/>
        <source>Could not compress &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="785"/>
        <source> alias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="788"/>
        <source> alias %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filemenu.cpp" line="809"/>
        <source>Filer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Fm::FileOperation</name>
    <message>
        <location filename="../fileoperation.cpp" line="223"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../fileoperation.cpp" line="224"/>
        <source>Some files cannot be moved to trash can because the underlying file systems don&apos;t support this operation.
Do you want to delete them instead?</source>
        <translation>Alguns arquivos não podem ser movidos para a lixeira porque o sistema de arquivos não suporta esta operação.
Deseja excluí-los permanentemente?</translation>
    </message>
    <message>
        <location filename="../fileoperation.cpp" line="273"/>
        <source>%1 is required by the system and cannot be deleted.</source>
        <translation>%1 é exigido pelo sistema e não pode ser excluído.</translation>
    </message>
    <message>
        <location filename="../fileoperation.cpp" line="281"/>
        <location filename="../fileoperation.cpp" line="313"/>
        <source>Confirm</source>
        <translation>Confirmação</translation>
    </message>
    <message>
        <location filename="../fileoperation.cpp" line="282"/>
        <source>Do you want to delete the selected files?</source>
        <translation>Deseja excluir permanentemente os arquivos selecionados?</translation>
    </message>
    <message>
        <location filename="../fileoperation.cpp" line="272"/>
        <location filename="../fileoperation.cpp" line="304"/>
        <source> </source>
        <translation> </translation>
    </message>
    <message>
        <location filename="../fileoperation.cpp" line="305"/>
        <source>%1 is required by the system and cannot be moved to the Trash.</source>
        <translation>%1 é exigido pelo sistema e não pode ser movido para a Lixeira.</translation>
    </message>
    <message>
        <location filename="../fileoperation.cpp" line="314"/>
        <source>Do you want to move the selected files to trash can?</source>
        <translation>Deseja mover os arquivos selecionados para a lixeira?</translation>
    </message>
</context>
<context>
    <name>Fm::FileOperationDialog</name>
    <message>
        <location filename="../fileoperationdialog.cpp" line="43"/>
        <source>Move files</source>
        <translation>Mover arquivos</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="44"/>
        <source>Moving the following files to destination folder:</source>
        <translation>Movendo os seguintes arquivos para a pasta de destino:</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="47"/>
        <source>Copy Files</source>
        <translation>Copiar Arquivos</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="48"/>
        <source>Copying the following files to destination folder:</source>
        <translation>Copiando os seguintes arquivos para a pasta de destino:</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="51"/>
        <source>Trash Files</source>
        <translation>Excluir os Arquivos</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="52"/>
        <source>Moving the following files to trash can:</source>
        <translation>Movendo os seguintes arquivos para a lixeira:</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="55"/>
        <source>Delete Files</source>
        <translation>Excluir Arquivos</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="56"/>
        <source>Deleting the following files</source>
        <translation>Excluindo os seguintes arquivos</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="61"/>
        <source>Create Symlinks</source>
        <translation>Criar Links Simbólicos</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="62"/>
        <source>Creating symlinks for the following files:</source>
        <translation>Criando links simbólicos para os seguintes arquivos:</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="65"/>
        <source>Change Attributes</source>
        <translation>Alterar Atributos</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="66"/>
        <source>Changing attributes of the following files:</source>
        <translation>Alterando os atributos destes arquivos:</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="71"/>
        <source>Restore Trashed Files</source>
        <translation>Restaurar Arquivos da Lixeira</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="72"/>
        <source>Restoring the following files from trash can:</source>
        <translation>Restaurar os seguintes arquivos da lixeira:</translation>
    </message>
    <message>
        <location filename="../fileoperationdialog.cpp" line="141"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
</context>
<context>
    <name>Fm::FilePropsDialog</name>
    <message>
        <location filename="../filepropsdialog.cpp" line="148"/>
        <source>View folder content</source>
        <translation>Ver conteúdo da pasta</translation>
    </message>
    <message>
        <location filename="../filepropsdialog.cpp" line="149"/>
        <source>View and modify folder content</source>
        <translation>Ver e modificar conteúdo da pasta</translation>
    </message>
    <message>
        <location filename="../filepropsdialog.cpp" line="153"/>
        <source>Read</source>
        <translation>Leitura</translation>
    </message>
    <message>
        <location filename="../filepropsdialog.cpp" line="154"/>
        <source>Read and write</source>
        <translation>Leitura e escrita</translation>
    </message>
    <message>
        <location filename="../filepropsdialog.cpp" line="156"/>
        <source>Forbidden</source>
        <translation>Proibido</translation>
    </message>
    <message>
        <location filename="../filepropsdialog.cpp" line="270"/>
        <source>Files of different types</source>
        <translation>Arquivos de outro tipo</translation>
    </message>
    <message>
        <location filename="../filepropsdialog.cpp" line="300"/>
        <source>Multiple Files</source>
        <translation>Vários arquivos</translation>
    </message>
    <message>
        <location filename="../filepropsdialog.cpp" line="428"/>
        <source>Apply changes</source>
        <translation>Aplicar alterações</translation>
    </message>
    <message>
        <location filename="../filepropsdialog.cpp" line="429"/>
        <source>Do you want to recursively apply these changes to all files and sub-folders?</source>
        <translation>Deseja aplicar as alterações a todos os ficheiros e subpastas?</translation>
    </message>
</context>
<context>
    <name>Fm::FileSearchDialog</name>
    <message>
        <location filename="../filesearchdialog.cpp" line="120"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../filesearchdialog.cpp" line="120"/>
        <source>You should add at least add one directory to search.</source>
        <translation>Adicione pelo menos uma pasta para pesquisar.</translation>
    </message>
    <message>
        <location filename="../filesearchdialog.cpp" line="127"/>
        <source>Select a folder</source>
        <translation>Selecionar uma pasta</translation>
    </message>
</context>
<context>
    <name>Fm::FolderItemDelegate</name>
    <message>
        <location filename="../folderitemdelegate.cpp" line="104"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../folderitemdelegate.cpp" line="104"/>
        <source>1 item</source>
        <translation type="unfinished">1 item</translation>
    </message>
    <message>
        <location filename="../folderitemdelegate.cpp" line="104"/>
        <source>%1 items</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Fm::FolderMenu</name>
    <message>
        <location filename="../foldermenu.cpp" line="37"/>
        <source>Create &amp;New</source>
        <translation>Criar &amp;Novo</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="44"/>
        <source>&amp;Paste</source>
        <translation>Co&amp;lar</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="50"/>
        <source>Select &amp;All</source>
        <translation>Selecion&amp;ar tudo</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation type="vanished">Inverter Seleção</translation>
    </message>
    <message>
        <source>Sorting</source>
        <translation type="vanished">Ordenação</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="56"/>
        <source>Sort By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="65"/>
        <source>Clean Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="69"/>
        <source>Clean Up By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="72"/>
        <source>Name</source>
        <translation type="unfinished">Nome</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="73"/>
        <source>Kind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="74"/>
        <source>Date Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="75"/>
        <source>Date Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="76"/>
        <source>Size</source>
        <translation type="unfinished">Tamanho</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="77"/>
        <source>Tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="86"/>
        <source>Show Hidden</source>
        <translation>Mostrar Ocultos</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="94"/>
        <source>Get Info</source>
        <translation>Informações</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="120"/>
        <source>By File Name</source>
        <translation>Por Nome de Arquivo</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="121"/>
        <source>By Modification Time</source>
        <translation>Por Data de Modificação</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="122"/>
        <source>By File Size</source>
        <translation>Por Tamanho de Arquivo</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="123"/>
        <source>By File Type</source>
        <translation>Por Tipo de Arquivo</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="124"/>
        <source>By File Owner</source>
        <translation>Por Dono de Arquivo</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="136"/>
        <source>Ascending</source>
        <translation>Ascendente</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="141"/>
        <source>Descending</source>
        <translation>Descendente</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="156"/>
        <source>Folder First</source>
        <translation>Pastas Primeiro</translation>
    </message>
    <message>
        <location filename="../foldermenu.cpp" line="165"/>
        <source>Case Sensitive</source>
        <translation>Diferenciar Maiúsculas</translation>
    </message>
</context>
<context>
    <name>Fm::FolderModel</name>
    <message>
        <location filename="../foldermodel.cpp" line="403"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../foldermodel.cpp" line="406"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../foldermodel.cpp" line="409"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../foldermodel.cpp" line="412"/>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <location filename="../foldermodel.cpp" line="415"/>
        <source>Date Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldermodel.cpp" line="418"/>
        <source>Tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../foldermodel.cpp" line="421"/>
        <source>Owner</source>
        <translation>Dono</translation>
    </message>
</context>
<context>
    <name>Fm::FontButton</name>
    <message>
        <location filename="../fontbutton.cpp" line="46"/>
        <source>Bold</source>
        <translation>Negrito</translation>
    </message>
    <message>
        <location filename="../fontbutton.cpp" line="50"/>
        <source>Italic</source>
        <translation>Itálico</translation>
    </message>
</context>
<context>
    <name>Fm::MountOperationPasswordDialog</name>
    <message>
        <location filename="../mountoperationpassworddialog.cpp" line="40"/>
        <source>&amp;Connect</source>
        <translation>&amp;Conectar</translation>
    </message>
</context>
<context>
    <name>Fm::PlacesModel</name>
    <message>
        <source>Places</source>
        <translation type="vanished">Locais</translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="263"/>
        <source>Locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="219"/>
        <source>Favorites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="203"/>
        <source>Recents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="212"/>
        <source>Shared</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="232"/>
        <source>Applications</source>
        <translation type="unfinished">Aplicativos</translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="239"/>
        <source>Desktop</source>
        <translation>Área de trabalho</translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="247"/>
        <source>Documents</source>
        <translation type="unfinished">Documentos</translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="256"/>
        <source>Downloads</source>
        <translation type="unfinished">Downloads</translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="272"/>
        <location filename="../placesmodel.cpp" line="278"/>
        <source>pCloud Drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="293"/>
        <source>PearDrop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="348"/>
        <source>Tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="371"/>
        <source>All Tags...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Computer</source>
        <translation type="vanished">Computador</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="vanished">Rede</translation>
    </message>
    <message>
        <source>Devices</source>
        <translation type="vanished">Dispositivos</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="vanished">Favoritos</translation>
    </message>
    <message>
        <location filename="../placesmodel.cpp" line="450"/>
        <source>Trash</source>
        <translation>Lixeira</translation>
    </message>
</context>
<context>
    <name>Fm::PlacesView</name>
    <message>
        <location filename="../placesview.cpp" line="667"/>
        <source>Open in New Window</source>
        <translation>Abrir em uma Nova Janela</translation>
    </message>
    <message>
        <location filename="../placesview.cpp" line="683"/>
        <source>Open in New Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesview.cpp" line="688"/>
        <source>Show in Enclosing Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesview.cpp" line="696"/>
        <source>Remove from Sidebar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesview.cpp" line="702"/>
        <source>Get Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesview.cpp" line="707"/>
        <source>Add to Dock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../placesview.cpp" line="716"/>
        <source>Empty Trash</source>
        <translation>Esvaziar Lixeira</translation>
    </message>
    <message>
        <source>Move Bookmark Up</source>
        <translation type="vanished">Mover Favorito para Cima</translation>
    </message>
    <message>
        <source>Move Bookmark Down</source>
        <translation type="vanished">Mover Favorito para Cima</translation>
    </message>
    <message>
        <source>Rename Bookmark</source>
        <translation type="vanished">Renomear Favorito</translation>
    </message>
    <message>
        <source>Remove Bookmark</source>
        <translation type="vanished">Remover Favorito</translation>
    </message>
    <message>
        <location filename="../placesview.cpp" line="727"/>
        <location filename="../placesview.cpp" line="744"/>
        <source>Unmount</source>
        <translation>Desmontar</translation>
    </message>
    <message>
        <location filename="../placesview.cpp" line="731"/>
        <source>Mount</source>
        <translation>Montar</translation>
    </message>
    <message>
        <location filename="../placesview.cpp" line="737"/>
        <source>Eject</source>
        <translation>Ejetar</translation>
    </message>
    <message>
        <location filename="../placesview.cpp" line="750"/>
        <source>Eject &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Fm::RenameDialog</name>
    <message>
        <location filename="../renamedialog.cpp" line="50"/>
        <location filename="../renamedialog.cpp" line="69"/>
        <source>Type: %1
Size: %2
Modified: %3</source>
        <translation>Tipo: %1
Tamanho: %2
Modificado: %3</translation>
    </message>
    <message>
        <location filename="../renamedialog.cpp" line="56"/>
        <source>Type: %1
Modified: %2</source>
        <translation>Tipo: %1
Modificado: %2</translation>
    </message>
    <message>
        <location filename="../renamedialog.cpp" line="75"/>
        <source>Type: %1
Modified: %3</source>
        <translation>Tipo: %1
Modificado: %3</translation>
    </message>
    <message>
        <location filename="../renamedialog.cpp" line="89"/>
        <source>&amp;Overwrite</source>
        <translation>&amp;Substituir</translation>
    </message>
    <message>
        <location filename="../renamedialog.cpp" line="91"/>
        <source>&amp;Rename</source>
        <translation>&amp;Renomear</translation>
    </message>
</context>
<context>
    <name>Fm::SidePane</name>
    <message>
        <location filename="../sidepane.cpp" line="218"/>
        <location filename="../sidepane.cpp" line="388"/>
        <source>Places</source>
        <translation>Locais</translation>
    </message>
    <message>
        <location filename="../sidepane.cpp" line="219"/>
        <location filename="../sidepane.cpp" line="390"/>
        <source>Directory Tree</source>
        <translation>Árvore de Pastas</translation>
    </message>
    <message>
        <location filename="../sidepane.cpp" line="398"/>
        <source>Shows list of common places, devices, and bookmarks in sidebar</source>
        <translation>Mostra a lista de locais comuns, dispositivos e favoritos na barra lateral</translation>
    </message>
    <message>
        <location filename="../sidepane.cpp" line="400"/>
        <source>Shows tree of directories in sidebar</source>
        <translation>Mostra a árvore de pastas na barra lateral</translation>
    </message>
</context>
<context>
    <name>GlideEffectConfig</name>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="19"/>
        <source>Duration:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="32"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="35"/>
        <source> milliseconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="50"/>
        <source>Window Open Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="56"/>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="154"/>
        <source>Rotation edge:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="70"/>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="168"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="75"/>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="173"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="80"/>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="178"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="85"/>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="183"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="93"/>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="191"/>
        <source>Rotation angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="119"/>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="198"/>
        <source>Distance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/glide/glide_config.ui" line="148"/>
        <source>Window Close Animation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GroupedActions</name>
    <message>
        <location filename="../../filer-topbar/build/bin/plasmoids/luisbocanegra.panelspacer.extended/contents/ui/components/GroupedActions.qml" line="127"/>
        <location filename="../../filer-topbar/plasmoids/luisbocanegra.panelspacer.extended/contents/ui/components/GroupedActions.qml" line="127"/>
        <source>command script or executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../filer-topbar/build/bin/plasmoids/luisbocanegra.panelspacer.extended/contents/ui/components/GroupedActions.qml" line="242"/>
        <location filename="../../filer-topbar/plasmoids/luisbocanegra.panelspacer.extended/contents/ui/components/GroupedActions.qml" line="242"/>
        <source>Enter URL or pick a file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HideCursorEffectConfig</name>
    <message>
        <location filename="../../kwin/src/plugins/hidecursor/hidecursor_config.ui" line="17"/>
        <source>Hide pointer on inactivity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/hidecursor/hidecursor_config.ui" line="24"/>
        <source>Hide pointer on typing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWin::LoginEffectConfigForm</name>
    <message>
        <location filename="../../kwin/src/plugins/login/package/contents/ui/config.ui" line="17"/>
        <source>Fade to black (fullscreen splash screens only)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWin::MagicLampEffectConfigForm</name>
    <message>
        <location filename="../../kwin/src/plugins/magiclamp/magiclamp_config.ui" line="17"/>
        <source>Animation duration:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/magiclamp/magiclamp_config.ui" line="36"/>
        <source>Default</source>
        <comment>Duration of rotation</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/magiclamp/magiclamp_config.ui" line="39"/>
        <source> milliseconds</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWin::MouseClickEffectConfigForm</name>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="21"/>
        <source>Basic Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="37"/>
        <source>Left Mouse Button Color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="50"/>
        <source>Middle Mouse Button Color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="70"/>
        <source>Right Mouse Button Color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="91"/>
        <source>Advanced Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="97"/>
        <source>Rings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="103"/>
        <source>Line Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="119"/>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="171"/>
        <source> pixel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="132"/>
        <source> msec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="145"/>
        <source>Ring Duration:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="155"/>
        <source>Ring Radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="184"/>
        <source>Ring Count:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="210"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="216"/>
        <source>Font:</source>
        <translation type="unfinished">Fonte:</translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mouseclick/mouseclick_config.ui" line="233"/>
        <source>Show Text:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWin::MouseMarkEffectConfigForm</name>
    <message>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="17"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="23"/>
        <source>Wid&amp;th:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="36"/>
        <source>&amp;Color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="82"/>
        <source>Draw with the mouse by holding modifier keys and moving the mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="103"/>
        <source>Free draw modifier keys:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="125"/>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="179"/>
        <source>Alt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="132"/>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="186"/>
        <source>Ctrl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="139"/>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="193"/>
        <source>Shift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="146"/>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="200"/>
        <source>Meta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/mousemark/mousemark_config.ui" line="157"/>
        <source>Arrow draw modifier keys:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWin::ThumbnailAsideEffectConfigForm</name>
    <message>
        <location filename="../../kwin/src/plugins/thumbnailaside/thumbnailaside_config.ui" line="17"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/thumbnailaside/thumbnailaside_config.ui" line="23"/>
        <source>Maximum &amp;width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/thumbnailaside/thumbnailaside_config.ui" line="36"/>
        <source>&amp;Spacing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/thumbnailaside/thumbnailaside_config.ui" line="55"/>
        <location filename="../../kwin/src/plugins/thumbnailaside/thumbnailaside_config.ui" line="106"/>
        <source> pixels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/thumbnailaside/thumbnailaside_config.ui" line="68"/>
        <source>&amp;Opacity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/thumbnailaside/thumbnailaside_config.ui" line="87"/>
        <source> %</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWin::TrackMouseEffectConfigForm</name>
    <message>
        <location filename="../../kwin/src/plugins/trackmouse/trackmouse_config.ui" line="26"/>
        <source>Trigger effect with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/trackmouse/trackmouse_config.ui" line="33"/>
        <source>Keyboard shortcut:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/trackmouse/trackmouse_config.ui" line="43"/>
        <source>Modifier keys:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/trackmouse/trackmouse_config.ui" line="65"/>
        <source>Alt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/trackmouse/trackmouse_config.ui" line="72"/>
        <source>Ctrl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/trackmouse/trackmouse_config.ui" line="79"/>
        <source>Shift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/trackmouse/trackmouse_config.ui" line="86"/>
        <source>Meta</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWin::TranslucencyEffectConfigForm</name>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="14"/>
        <source>Translucency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="20"/>
        <source>General Translucency Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="64"/>
        <source>Combobox popups:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="121"/>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="441"/>
        <source>Opaque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="137"/>
        <source>Dialogs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="156"/>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="428"/>
        <source>Transparent</source>
        <translation type="unfinished">Transparente</translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="188"/>
        <source>Menus:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="201"/>
        <source>Exclude fullscreen windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="217"/>
        <source>Moving windows:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="236"/>
        <source>Inactive windows:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="277"/>
        <source>Set menu translucency independently</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="295"/>
        <source>Dropdown menus:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="339"/>
        <source>Popup menus:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/translucency/package/contents/ui/config.ui" line="377"/>
        <source>Torn-off menus:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWin::VideoWallConfigForm</name>
    <message>
        <location filename="../../kwin/src/plugins/videowall/package/contents/ui/config.ui" line="14"/>
        <source>Video Wall</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/videowall/package/contents/ui/config.ui" line="20"/>
        <source>Apply to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/videowall/package/contents/ui/config.ui" line="32"/>
        <source>vlc, xv, vdpau, smplayer, dragon, xine, ffplay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/videowall/package/contents/ui/config.ui" line="35"/>
        <location filename="../../kwin/src/plugins/videowall/package/contents/ui/config.ui" line="66"/>
        <source>Comma separated list of window classes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/videowall/package/contents/ui/config.ui" line="45"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/videowall/package/contents/ui/config.ui" line="54"/>
        <source>Ignore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/videowall/package/contents/ui/config.ui" line="73"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWinActionsConfigForm</name>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="20"/>
        <source>Inactive Inner Window Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="29"/>
        <source>&amp;Left click:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="42"/>
        <source>In this row you can customize left click behavior when clicking into an inactive inner window (&apos;inner&apos; means: not titlebar, not frame).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="46"/>
        <source>Activate, pass click and raise on release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="51"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="91"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="131"/>
        <source>Activate, raise and pass click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="56"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="96"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="136"/>
        <source>Activate and pass click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="61"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="101"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="141"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="66"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="106"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="146"/>
        <source>Activate and raise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="74"/>
        <source>&amp;Middle click:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="87"/>
        <source>In this row you can customize middle click behavior when clicking into an inactive inner window (&apos;inner&apos; means: not titlebar, not frame).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="114"/>
        <source>&amp;Right click:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="127"/>
        <source>In this row you can customize right click behavior when clicking into an inactive inner window (&apos;inner&apos; means: not titlebar, not frame).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="154"/>
        <source>Mouse &amp;wheel:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="167"/>
        <source>In this row you can customize behavior when scrolling into an inactive inner window (&apos;inner&apos; means: not titlebar, not frame).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="171"/>
        <source>Scroll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="176"/>
        <source>Activate and scroll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="181"/>
        <source>Activate, raise and scroll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="195"/>
        <source>Inner Window, Titlebar and Frame Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="206"/>
        <source>Mo&amp;difier key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="216"/>
        <source>Here you select whether holding the Meta key or Alt key will allow you to perform the following actions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="220"/>
        <source>Meta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="225"/>
        <source>Alt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="247"/>
        <source>  + </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="259"/>
        <source>L&amp;eft click:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="272"/>
        <source>In this row you can customize left click behavior when clicking into the titlebar or the frame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="276"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="356"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="436"/>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="281"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="361"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="441"/>
        <source>Activate, raise and move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="286"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="366"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="446"/>
        <source>Activate, raise and resize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="291"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="371"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="451"/>
        <source>Toggle raise and lower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="296"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="376"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="456"/>
        <source>Resize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="301"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="381"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="461"/>
        <source>Raise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="306"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="386"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="466"/>
        <source>Lower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="311"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="391"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="471"/>
        <source>Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="316"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="396"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="476"/>
        <source>Decrease opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="321"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="401"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="481"/>
        <source>Increase opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="326"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="406"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="486"/>
        <source>Window menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="331"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="411"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="491"/>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="541"/>
        <source>Do nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="339"/>
        <source>Middle &amp;click:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="352"/>
        <source>In this row you can customize middle click behavior when clicking into the titlebar or the frame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="419"/>
        <source>Right clic&amp;k:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="432"/>
        <source>In this row you can customize right click behavior when clicking into the titlebar or the frame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="499"/>
        <source>Mo&amp;use wheel:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="512"/>
        <source>Here you can customize KDE&apos;s behavior when scrolling with the mouse wheel in a window while pressing the modifier key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="516"/>
        <source>Raise/lower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="521"/>
        <source>Maximize/restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="526"/>
        <source>Keep above/below</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="531"/>
        <source>Move to previous/next desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/actions.ui" line="536"/>
        <source>Change opacity</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWinAdvancedConfigForm</name>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="20"/>
        <source>Window &amp;placement:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="30"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The placement policy determines where a new window will appear on the desktop.&lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Smart&lt;/span&gt; will try to achieve a minimum overlap of windows&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Maximizing&lt;/span&gt; will try to maximize every window to fill the whole screen. It might be useful to selectively affect placement of some windows using the window-specific settings.&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Random&lt;/span&gt; will use a random position&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Centered&lt;/span&gt; will place the window centered&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Zero-cornered&lt;/span&gt; will place the window in the top-left corner&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Under mouse&lt;/span&gt; will place the window under the pointer&lt;/li&gt;&lt;/ul&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="34"/>
        <source>Minimal Overlapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="39"/>
        <source>Maximized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="44"/>
        <source>Random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="49"/>
        <source>Centered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="54"/>
        <source>In Top-Left Corner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="59"/>
        <source>Under mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="67"/>
        <source>When turned on, apps which are able to remember the positions of their windows are allowed to do so. This will override the window placement mode defined above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="70"/>
        <source>Allow apps to remember the positions of their own windows, if they support it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="77"/>
        <source>Virtual Desktop behavior:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="87"/>
        <source>When activating a window on a different Virtual Desktop:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This setting controls what happens when an open window located on a Virtual Desktop other than the current one is activated. &lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Switch to that Virtual Desktop&lt;/span&gt; will switch to the Virtual Desktop where the window is currently located. &lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Bring window to current Virtual Desktop&lt;/span&gt; will cause the window to jump to the active Virtual Desktop. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="98"/>
        <source>Switch to that Virtual Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="103"/>
        <source>Bring window to current Virtual Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/advanced.ui" line="108"/>
        <source>Do nothing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWinFocusConfigForm</name>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="22"/>
        <source>Window &amp;activation policy:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="32"/>
        <source>With this option you can specify how and when windows will be focused.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="36"/>
        <source>Click to focus</source>
        <comment>sassa asas</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="41"/>
        <source>Click to focus (mouse precedence)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="46"/>
        <source>Focus follows mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="51"/>
        <source>Focus follows mouse (mouse precedence)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="56"/>
        <source>Focus under mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="61"/>
        <source>Focus strictly under mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="69"/>
        <source>&amp;Delay focus by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="82"/>
        <source>This is the delay after which the window the mouse pointer is over will automatically receive focus.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="85"/>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="181"/>
        <source> ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="101"/>
        <source>Focus &amp;stealing prevention:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="114"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option specifies how much KWin will try to prevent unwanted focus stealing caused by unexpected activation of new windows. (Note: This feature does not work with the &lt;span style=&quot; font-style:italic;&quot;&gt;Focus under mouse&lt;/span&gt; or &lt;span style=&quot; font-style:italic;&quot;&gt;Focus strictly under mouse&lt;/span&gt; focus policies.) &lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;None:&lt;/span&gt; Prevention is turned off and new windows always become activated.&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Low:&lt;/span&gt; Prevention is enabled; when some window does not have support for the underlying mechanism and KWin cannot reliably decide whether to activate the window or not, it will be activated. This setting may have both worse and better results than the medium level, depending on the applications.&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Medium:&lt;/span&gt; Prevention is enabled.&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;High:&lt;/span&gt; New windows get activated only if no window is currently active or if they belong to the currently active application. This setting is probably not really usable when not using mouse focus policy.&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Extreme:&lt;/span&gt; All windows must be explicitly activated by the user.&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;Windows that are prevented from stealing focus are marked as demanding attention, which by default means their taskbar entry will be highlighted. This can be changed in the Notifications control module.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="118"/>
        <source>None</source>
        <extracomment>Focus Stealing Prevention Level</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="123"/>
        <source>Low</source>
        <extracomment>Focus Stealing Prevention Level</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="128"/>
        <source>Medium</source>
        <extracomment>Focus Stealing Prevention Level</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="133"/>
        <source>High</source>
        <extracomment>Focus Stealing Prevention Level</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="138"/>
        <source>Extreme</source>
        <extracomment>Focus Stealing Prevention Level</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="146"/>
        <source>Raising windows:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="153"/>
        <source>When this option is enabled, the active window will be brought to the front when you click somewhere into the window contents. To change it for inactive windows, you need to change the settings in the Actions tab.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="156"/>
        <source>&amp;Click raises active window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="165"/>
        <source>When this option is enabled, a window in the background will automatically come to the front when the mouse pointer has been over it for some time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="168"/>
        <source>&amp;Raise on hover, delayed by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="178"/>
        <source>This is the delay after which the window that the mouse pointer is over will automatically come to the front.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="199"/>
        <source>Multiscreen behavior:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="206"/>
        <source>When this option is enabled, focus operations are limited only to the active screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="209"/>
        <source>&amp;Separate screen focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/focus.ui" line="222"/>
        <source>Window activation policy description</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWinMouseConfigForm</name>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="17"/>
        <source>Titlebar Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="29"/>
        <source>&amp;Double-click:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="39"/>
        <source>Behavior on &lt;em&gt;double&lt;/em&gt; click into the titlebar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="43"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="591"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="626"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="661"/>
        <source>Maximize</source>
        <extracomment>@item:inlistbox behavior on double click</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="48"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="596"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="631"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="666"/>
        <source>Vertically maximize</source>
        <extracomment>@item:inlistbox behavior on double click</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="53"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="601"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="636"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="671"/>
        <source>Horizontally maximize</source>
        <extracomment>@item:inlistbox behavior on double click</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="58"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="247"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="304"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="352"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="409"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="457"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="514"/>
        <source>Minimize</source>
        <extracomment>@item:inlistbox behavior on double click</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="63"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="237"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="294"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="342"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="399"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="447"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="504"/>
        <source>Lower</source>
        <extracomment>@item:inlistbox behavior on double click</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="68"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="252"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="309"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="357"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="414"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="462"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="519"/>
        <source>Close</source>
        <extracomment>@item:inlistbox behavior on double click</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="73"/>
        <source>Show on all desktops</source>
        <extracomment>@item:inlistbox behavior on double click</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="78"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="125"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="262"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="319"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="367"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="424"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="472"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="529"/>
        <source>Do nothing</source>
        <extracomment>@item:inlistbox behavior on double click</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="86"/>
        <source>Mouse &amp;wheel:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="96"/>
        <source>Behavior on &lt;em&gt;mouse wheel&lt;/em&gt; scroll over the titlebar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="100"/>
        <source>Raise/lower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="105"/>
        <source>Maximize/restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="110"/>
        <source>Keep above/below</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="115"/>
        <source>Move to previous/next desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="120"/>
        <source>Change opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="136"/>
        <source>Titlebar and Frame Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="163"/>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="173"/>
        <source>&amp;Left click:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="186"/>
        <source>Inactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="196"/>
        <source>&amp;Middle click:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="209"/>
        <source>&amp;Right click:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="228"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="333"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="438"/>
        <source>Behavior on &lt;em&gt;left&lt;/em&gt; click into the titlebar or frame of an &lt;em&gt;active&lt;/em&gt; window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="232"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="289"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="337"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="394"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="442"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="499"/>
        <source>Raise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="242"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="299"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="347"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="404"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="452"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="509"/>
        <source>Toggle raise and lower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="257"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="314"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="362"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="419"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="467"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="524"/>
        <source>Window menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="270"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="375"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="480"/>
        <source>Behavior on &lt;em&gt;left&lt;/em&gt; click into the titlebar or frame of an &lt;em&gt;inactive&lt;/em&gt; window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="274"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="379"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="484"/>
        <source>Activate and raise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="279"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="384"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="489"/>
        <source>Activate and lower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="284"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="389"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="494"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="537"/>
        <source>Maximize window by double clicking its frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="562"/>
        <source>Maximize Button Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="574"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="587"/>
        <source>Behavior on &lt;em&gt;left&lt;/em&gt; click onto the maximize button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="577"/>
        <source>L&amp;eft click:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="609"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="622"/>
        <source>Behavior on &lt;em&gt;middle&lt;/em&gt; click onto the maximize button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="612"/>
        <source>Middle c&amp;lick:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="644"/>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="657"/>
        <source>Behavior on &lt;em&gt;right&lt;/em&gt; click onto the maximize button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/mouse.ui" line="647"/>
        <source>Right clic&amp;k:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWinMovingConfigForm</name>
    <message>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="20"/>
        <source>Screen &amp;edge snap zone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="30"/>
        <source>Here you can set the snap zone for screen edges, i.e. the &apos;strength&apos; of the magnetic field which will make windows snap to the border when moved near it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="33"/>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="65"/>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="97"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="36"/>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="68"/>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="100"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="52"/>
        <source>&amp;Window snap zone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="62"/>
        <source>Here you can set the snap zone for windows, i.e. the &apos;strength&apos; of the magnetic field which will make windows snap to each other when they are moved near another window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="84"/>
        <source>&amp;Center snap zone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="94"/>
        <source>Here you can set the snap zone for the screen center, i.e. the &apos;strength&apos; of the magnetic field which will make windows snap to the center of the screen when moved near it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="113"/>
        <source>&amp;Snap windows:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="123"/>
        <source>Here you can set that windows will be only snapped if you try to overlap them, i.e. they will not be snapped if the windows comes only near another window or border.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/moving.ui" line="126"/>
        <source>Only when overlapping</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWinPipConfigForm</name>
    <message>
        <location filename="../../kwin/src/kcms/options/pip.ui" line="20"/>
        <source>Open in screen corner:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/pip.ui" line="31"/>
        <source>Top-left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/pip.ui" line="36"/>
        <source>Top-right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/pip.ui" line="41"/>
        <source>Bottom-left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/pip.ui" line="46"/>
        <source>Bottom-right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/pip.ui" line="54"/>
        <source>Margin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/options/pip.ui" line="61"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWinScreenEdgesConfigUI</name>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="23"/>
        <source>You can trigger an action by pushing the mouse pointer against the corresponding screen edge or corner.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="67"/>
        <source>&amp;Maximize:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="77"/>
        <source>Windows dragged to top edge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="84"/>
        <source>&amp;Tile:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="94"/>
        <source>Windows dragged to left or right edge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="101"/>
        <source>Behavior:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="108"/>
        <source>Remain active when windows are fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="115"/>
        <source>Trigger &amp;quarter tiling in:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="130"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="133"/>
        <source>Outer </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="149"/>
        <source>of the screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="174"/>
        <source>Change desktop when the mouse pointer is pushed against the edge of the screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="177"/>
        <source>&amp;Switch desktop on edge:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="188"/>
        <source>Disabled</source>
        <comment>Switch desktop on edge</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="193"/>
        <source>Only when moving windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="198"/>
        <source>Always enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="206"/>
        <source>Amount of time required for the mouse pointer to be pushed against the edge of the screen before the action is triggered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="209"/>
        <source>Activation &amp;delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="219"/>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="254"/>
        <source> ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="238"/>
        <source>Amount of time required after triggering an action until the next trigger can occur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="241"/>
        <source>&amp;Reactivation delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="270"/>
        <source>&amp;Corner barrier:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="280"/>
        <source>Here you can enable or disable the virtual corner barrier between screens. The barrier prevents the pointer from moving to another screen when it is already touching a screen corner. This makes it easier to trigger user interface elements like maximized windows&apos; close buttons when using multiple screens.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="283"/>
        <source>Prevents the pointer from crossing at screen corners.</source>
        <comment>@info:tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="290"/>
        <source>&amp;Edge barrier:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="300"/>
        <source>Here you can set size of the edge barrier between different screens. The barrier adds additional distance you have to move your pointer before it crosses the edge onto the other screen. This makes it easier to access user interface elements like Plasma Panels that are located on an edge between screens.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="303"/>
        <source>Additional distance the pointer needs to travel to cross screen edges.</source>
        <comment>@info:tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="306"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/main.ui" line="309"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWinTabBoxConfigForm</name>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="32"/>
        <source>Content</source>
        <translation type="unfinished">Conteúdo</translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="41"/>
        <source>Include &quot;Peek at Desktop&quot; entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="55"/>
        <source>Recently used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="60"/>
        <source>Stacking order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="68"/>
        <source>Only one window per application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="78"/>
        <source>Order minimized windows after unminimized windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="88"/>
        <source>Sort order:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="114"/>
        <source>Filter windows by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="123"/>
        <source>Virtual desktops</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="167"/>
        <source>Current desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="174"/>
        <source>All other desktops</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="184"/>
        <source>Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="228"/>
        <source>Current activity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="235"/>
        <source>All other activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="245"/>
        <source>Screens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="289"/>
        <source>Current screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="296"/>
        <source>All other screens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="306"/>
        <source>Minimization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="350"/>
        <source>Visible windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="357"/>
        <source>Hidden windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="396"/>
        <source>Shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="405"/>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="448"/>
        <source>Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="428"/>
        <source>All windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="438"/>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="458"/>
        <source>Reverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="474"/>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="506"/>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="554"/>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="586"/>
        <source>or</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="538"/>
        <source>Current application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="615"/>
        <source>Visualization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="624"/>
        <source>The currently selected window will be highlighted by fading out all other windows. This option requires desktop effects to be active.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="634"/>
        <source>Show selected window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="644"/>
        <source>Enable the window list effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="678"/>
        <source>The effect to replace the list window when desktop effects are active.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="701"/>
        <source>The time in milliseconds to wait before showing the task switcher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="704"/>
        <source>Delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="720"/>
        <source> ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="735"/>
        <source>Delay before the window list appears</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="742"/>
        <source>Show on screen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="758"/>
        <source>Select which screen the task switcher should be displayed on.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="762"/>
        <source>Active screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/kcms/tabbox/main.ui" line="767"/>
        <source>Primary screen</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KWinTouchScreenConfigUi</name>
    <message>
        <location filename="../../kwin/src/kcms/screenedges/touch.ui" line="17"/>
        <source>You can trigger an action by swiping from the screen edge towards the center of the screen.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KillDialog</name>
    <message>
        <location filename="../../kwin/src/helpers/killer/killdialog.ui" line="14"/>
        <source>Not Responding</source>
        <comment>@title:window</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/helpers/killer/killdialog.ui" line="53"/>
        <source>&amp;Details</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../main-win.ui" line="14"/>
        <location filename="../../build/src/ui_main-win.h" line="590"/>
        <source>File Manager</source>
        <translation>Gerenciador de Arquivos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="259"/>
        <location filename="../../build/src/ui_main-win.h" line="591"/>
        <source>Go &amp;Up</source>
        <translation>S&amp;ubir</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="262"/>
        <location filename="../../build/src/ui_main-win.h" line="593"/>
        <source>Go Up</source>
        <translation>Subir</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="274"/>
        <location filename="../../build/src/ui_main-win.h" line="598"/>
        <source>&amp;Home</source>
        <translation>&amp;Início</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="286"/>
        <location filename="../../build/src/ui_main-win.h" line="602"/>
        <source>&amp;Reload</source>
        <translation>&amp;Recarregar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="301"/>
        <location filename="../../build/src/ui_main-win.h" line="606"/>
        <source>Go</source>
        <translation>Ir</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="313"/>
        <location filename="../../build/src/ui_main-win.h" line="607"/>
        <source>Quit</source>
        <translation>Sair</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="331"/>
        <location filename="../../build/src/ui_main-win.h" line="609"/>
        <source>&amp;New Window</source>
        <translation>&amp;Nova Janela</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="334"/>
        <location filename="../../build/src/ui_main-win.h" line="611"/>
        <source>New Window</source>
        <translation>Nova Janela</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="337"/>
        <location filename="../../build/src/ui_main-win.h" line="614"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="345"/>
        <location filename="../../build/src/ui_main-win.h" line="616"/>
        <source>Show &amp;Hidden</source>
        <translation>Mostrar &amp;Ocultos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="354"/>
        <location filename="../../build/src/ui_main-win.h" line="617"/>
        <source>&amp;Computer</source>
        <translation>&amp;Computador</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="357"/>
        <location filename="../../build/src/ui_main-win.h" line="619"/>
        <source>Ctrl+Shift+C</source>
        <translation>Ctrl+Shift+C</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="366"/>
        <location filename="../../build/src/ui_main-win.h" line="621"/>
        <source>&amp;Trash</source>
        <translation>&amp;Lixeira</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="369"/>
        <location filename="../../build/src/ui_main-win.h" line="623"/>
        <source>Ctrl+Shift+T</source>
        <translation>Ctrl+Shift+T</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="374"/>
        <location filename="../../build/src/ui_main-win.h" line="625"/>
        <source>&amp;Network</source>
        <translation>&amp;Rede</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="386"/>
        <location filename="../../build/src/ui_main-win.h" line="629"/>
        <source>&amp;Desktop</source>
        <translation>Área &amp;de trabalho</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="389"/>
        <location filename="../../build/src/ui_main-win.h" line="631"/>
        <source>Ctrl+Shift+D</source>
        <translation>Ctrl+Shift+D</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="398"/>
        <location filename="../../build/src/ui_main-win.h" line="633"/>
        <source>&amp;Add to Bookmarks</source>
        <translation>&amp;Adicionar aos Favoritos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="403"/>
        <location filename="../../build/src/ui_main-win.h" line="634"/>
        <source>&amp;Applications</source>
        <translation>&amp;Aplicativos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="406"/>
        <location filename="../../build/src/ui_main-win.h" line="636"/>
        <source>Ctrl+Shift+A</source>
        <translation>Ctrl+Shift+A</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="414"/>
        <location filename="../../build/src/ui_main-win.h" line="638"/>
        <source>Reload</source>
        <translation>Recarregar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="422"/>
        <location filename="../../build/src/ui_main-win.h" line="639"/>
        <source>&amp;Icon View</source>
        <translation>V&amp;isão de Ícones</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="425"/>
        <location filename="../../build/src/ui_main-win.h" line="641"/>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <source>&amp;Compact View</source>
        <translation type="vanished">Visão &amp;Compacta</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="433"/>
        <location filename="../../build/src/ui_main-win.h" line="643"/>
        <source>&amp;Detailed List</source>
        <translation>Lista &amp;Detalhada</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="436"/>
        <location filename="../../build/src/ui_main-win.h" line="645"/>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="444"/>
        <location filename="../../build/src/ui_main-win.h" line="647"/>
        <source>&amp;Thumbnail View</source>
        <translation>Visão de &amp;Miniaturas</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="453"/>
        <location filename="../../build/src/ui_main-win.h" line="648"/>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="456"/>
        <location filename="../../build/src/ui_main-win.h" line="650"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="465"/>
        <location filename="../../build/src/ui_main-win.h" line="652"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="468"/>
        <location filename="../../build/src/ui_main-win.h" line="654"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="477"/>
        <location filename="../../build/src/ui_main-win.h" line="656"/>
        <source>&amp;Paste</source>
        <translation>Co&amp;lar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="480"/>
        <location filename="../../build/src/ui_main-win.h" line="658"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="485"/>
        <location filename="../../build/src/ui_main-win.h" line="660"/>
        <source>Select &amp;All</source>
        <translation>Selecion&amp;ar Tudo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="488"/>
        <location filename="../../build/src/ui_main-win.h" line="662"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="493"/>
        <location filename="../../build/src/ui_main-win.h" line="664"/>
        <source>Pr&amp;eferences</source>
        <translation>Pr&amp;eferências</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="496"/>
        <location filename="../../build/src/ui_main-win.h" line="666"/>
        <source>Ctrl+,</source>
        <translation>Ctrl+,</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="504"/>
        <location filename="../../build/src/ui_main-win.h" line="668"/>
        <source>&amp;Ascending</source>
        <translation>&amp;Ascendente</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="512"/>
        <location filename="../../build/src/ui_main-win.h" line="669"/>
        <source>&amp;Descending</source>
        <translation>&amp;Descendente</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="520"/>
        <location filename="../../build/src/ui_main-win.h" line="670"/>
        <source>&amp;By File Name</source>
        <translation>&amp;Por Nome de Arquivo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="528"/>
        <location filename="../../build/src/ui_main-win.h" line="671"/>
        <source>By &amp;Modification Time</source>
        <translation>Por Data de &amp;Modificação</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="536"/>
        <location filename="../../build/src/ui_main-win.h" line="672"/>
        <source>By File &amp;Type</source>
        <translation>Por &amp;Tipo de Arquivo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="544"/>
        <location filename="../../build/src/ui_main-win.h" line="673"/>
        <source>By &amp;Owner</source>
        <translation>Por &amp;Dono</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="552"/>
        <location filename="../../build/src/ui_main-win.h" line="674"/>
        <source>&amp;Folder First</source>
        <translation>&amp;Pastas primeiro</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="623"/>
        <location filename="../../build/src/ui_main-win.h" line="697"/>
        <source>&amp;Move to Trash</source>
        <translation>&amp;Mover para a Lixeira</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="812"/>
        <location filename="../../build/src/ui_main-win.h" line="774"/>
        <source>Meta+Shift+Backspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Backspace</source>
        <translation type="vanished">Ctrl+Backspace</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="644"/>
        <location filename="../../build/src/ui_main-win.h" line="706"/>
        <source>Get &amp;Info</source>
        <translation>&amp;Informações</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="647"/>
        <location filename="../../build/src/ui_main-win.h" line="708"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="655"/>
        <location filename="../../build/src/ui_main-win.h" line="710"/>
        <source>&amp;Case Sensitive</source>
        <translation>&amp;Diferenciar Maiúsculas</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="663"/>
        <location filename="../../build/src/ui_main-win.h" line="711"/>
        <source>By File &amp;Size</source>
        <translation>Por &amp;Tamanho de Arquivo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="668"/>
        <location filename="../../build/src/ui_main-win.h" line="712"/>
        <source>&amp;Close Window</source>
        <translation>Fe&amp;char Janela</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="703"/>
        <location filename="../../build/src/ui_main-win.h" line="723"/>
        <source>&amp;Folder</source>
        <translation>&amp;Pasta</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="715"/>
        <location filename="../../build/src/ui_main-win.h" line="727"/>
        <source>&amp;Blank File</source>
        <translation>&amp;Arquivo Vazio</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="726"/>
        <location filename="../../build/src/ui_main-win.h" line="733"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="740"/>
        <location filename="../../build/src/ui_main-win.h" line="736"/>
        <source>&amp;Go To Folder</source>
        <translation>&amp;Ir para Pasta</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="743"/>
        <location filename="../../build/src/ui_main-win.h" line="738"/>
        <source>Go To Folder</source>
        <translation>Ir para Pasta</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="746"/>
        <location filename="../../build/src/ui_main-win.h" line="741"/>
        <source>Ctrl+Shift+G</source>
        <translation>Ctrl+Shift+G</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="751"/>
        <location filename="../../build/src/ui_main-win.h" line="743"/>
        <source>&amp;Downloads</source>
        <translation>&amp;Downloads</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="754"/>
        <location filename="../../build/src/ui_main-win.h" line="745"/>
        <source>Downloads</source>
        <translation>Downloads</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="757"/>
        <location filename="../../build/src/ui_main-win.h" line="748"/>
        <source>Ctrl+Shift+L</source>
        <translation>Ctrl+Shift+L</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="765"/>
        <location filename="../../build/src/ui_main-win.h" line="750"/>
        <source>&amp;Utilities</source>
        <translation>&amp;Utilitários</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="768"/>
        <location filename="../../build/src/ui_main-win.h" line="752"/>
        <source>Utilities</source>
        <translation>Utilitários</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="771"/>
        <location filename="../../build/src/ui_main-win.h" line="755"/>
        <source>Ctrl+Shift+U</source>
        <translation>Ctrl+Shift+U</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="779"/>
        <location filename="../../build/src/ui_main-win.h" line="757"/>
        <source>&amp;Documents</source>
        <translation>&amp;Documentos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="782"/>
        <location filename="../../build/src/ui_main-win.h" line="759"/>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="785"/>
        <location filename="../../build/src/ui_main-win.h" line="762"/>
        <source>Ctrl+Shift+O</source>
        <translation>Ctrl+Shift+O</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="793"/>
        <location filename="../../build/src/ui_main-win.h" line="764"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="796"/>
        <location filename="../../build/src/ui_main-win.h" line="766"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="801"/>
        <location filename="../../build/src/ui_main-win.h" line="768"/>
        <source>&amp;Duplicate</source>
        <translation>&amp;Duplicar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="804"/>
        <location filename="../../build/src/ui_main-win.h" line="770"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="809"/>
        <location filename="../../build/src/ui_main-win.h" line="772"/>
        <source>Empty Trash</source>
        <translation>Esvaziar Lixeira</translation>
    </message>
    <message>
        <source>Ctrl+Alt+Backspace</source>
        <translation type="vanished">Ctrl+Alt+Backspace</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="817"/>
        <location filename="../../build/src/ui_main-win.h" line="776"/>
        <source>Show Contents</source>
        <translation>Mostrar Conteúdo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="820"/>
        <location filename="../../build/src/ui_main-win.h" line="778"/>
        <source>Ctrl+Alt+Shift+O</source>
        <translation>Ctrl+Alt+Shift+O</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="843"/>
        <location filename="../../build/src/ui_main-win.h" line="789"/>
        <source>Ctrl+Alt+O</source>
        <translation>Ctrl+Alt+O</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="829"/>
        <location filename="../main-win.ui" line="832"/>
        <location filename="../../build/src/ui_main-win.h" line="780"/>
        <location filename="../../build/src/ui_main-win.h" line="782"/>
        <source>Go Up and Close Current</source>
        <translation>Subir e Fechar Atual</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="835"/>
        <location filename="../../build/src/ui_main-win.h" line="785"/>
        <source>Ctrl+Shift+Up</source>
        <translation>Ctrl+Shift+Up</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="840"/>
        <location filename="../../build/src/ui_main-win.h" line="787"/>
        <source>Open With...</source>
        <translation>Abrir com...</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="561"/>
        <location filename="../../build/src/ui_main-win.h" line="675"/>
        <source>New &amp;Tab</source>
        <translation>Nova &amp;Aba</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="265"/>
        <location filename="../../build/src/ui_main-win.h" line="596"/>
        <source>Ctrl+Up</source>
        <translation>Ctrl+Up</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="277"/>
        <location filename="../../build/src/ui_main-win.h" line="600"/>
        <source>Ctrl+Shift+H</source>
        <translation>Ctrl+Shift+H</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="289"/>
        <location filename="../../build/src/ui_main-win.h" line="604"/>
        <source>Ctrl+Shift+R</source>
        <translation>Ctrl+Shift+R</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="322"/>
        <location filename="../../build/src/ui_main-win.h" line="608"/>
        <source>&amp;About Filer</source>
        <translation>&amp;Sobre o Filer</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="564"/>
        <location filename="../../build/src/ui_main-win.h" line="677"/>
        <source>New Tab</source>
        <translation>Nova Aba</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="567"/>
        <location filename="../main-win.ui" line="684"/>
        <location filename="../../build/src/ui_main-win.h" line="680"/>
        <location filename="../../build/src/ui_main-win.h" line="719"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="579"/>
        <location filename="../../build/src/ui_main-win.h" line="682"/>
        <source>Go &amp;Back</source>
        <translation>&amp;Voltar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="582"/>
        <location filename="../../build/src/ui_main-win.h" line="684"/>
        <source>Go Back</source>
        <translation>Voltar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="585"/>
        <location filename="../../build/src/ui_main-win.h" line="687"/>
        <source>Alt+Left</source>
        <translation>Alt+Esquerda</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="594"/>
        <location filename="../../build/src/ui_main-win.h" line="689"/>
        <source>Go &amp;Forward</source>
        <translation>&amp;Avançar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="597"/>
        <location filename="../../build/src/ui_main-win.h" line="691"/>
        <source>Go Forward</source>
        <translation>Avançar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="600"/>
        <location filename="../../build/src/ui_main-win.h" line="694"/>
        <source>Alt+Right</source>
        <translation>Alt+Right</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="614"/>
        <location filename="../../build/src/ui_main-win.h" line="696"/>
        <source>&amp;Invert Selection</source>
        <translation>&amp;Inverter Seleção</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="626"/>
        <location filename="../../build/src/ui_main-win.h" line="699"/>
        <source>Meta+Backspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="631"/>
        <location filename="../../build/src/ui_main-win.h" line="701"/>
        <source>&amp;Rename</source>
        <translation>&amp;Renomear</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="634"/>
        <location filename="../../build/src/ui_main-win.h" line="703"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="639"/>
        <location filename="../../build/src/ui_main-win.h" line="705"/>
        <source>C&amp;lose Tab</source>
        <translation>&amp;Fechar Aba</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="671"/>
        <location filename="../../build/src/ui_main-win.h" line="714"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="676"/>
        <location filename="../../build/src/ui_main-win.h" line="716"/>
        <source>Edit Bookmarks</source>
        <translation>Editar Favoritos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="681"/>
        <location filename="../../build/src/ui_main-win.h" line="717"/>
        <source>Open &amp;Terminal</source>
        <translation>Abrir &amp;Terminal</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="689"/>
        <location filename="../../build/src/ui_main-win.h" line="721"/>
        <source>Open as &amp;Root</source>
        <translation>Abrir como &amp;Administrador</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="694"/>
        <location filename="../../build/src/ui_main-win.h" line="722"/>
        <source>&amp;Edit Bookmarks</source>
        <translation>&amp;Editar Favoritos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="377"/>
        <location filename="../main-win.ui" line="706"/>
        <location filename="../../build/src/ui_main-win.h" line="627"/>
        <location filename="../../build/src/ui_main-win.h" line="725"/>
        <source>Ctrl+Shift+N</source>
        <translation>Ctrl+Shift+N</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="718"/>
        <location filename="../../build/src/ui_main-win.h" line="729"/>
        <source>Ctrl+Alt+N</source>
        <translation>Ctrl+Alt+N</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="723"/>
        <location filename="../../build/src/ui_main-win.h" line="731"/>
        <source>&amp;Find Files</source>
        <translation>&amp;Procurar Arquivos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="731"/>
        <location filename="../../build/src/ui_main-win.h" line="735"/>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <source>Filter by string...</source>
        <translation type="vanished">Filtrar por linha...</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="107"/>
        <location filename="../../build/src/ui_main-win.h" line="791"/>
        <source>&amp;File</source>
        <translation>&amp;Arquivo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="111"/>
        <location filename="../../build/src/ui_main-win.h" line="792"/>
        <source>C&amp;reate New</source>
        <translation>C&amp;riar novo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="131"/>
        <location filename="../../build/src/ui_main-win.h" line="793"/>
        <source>&amp;Help</source>
        <translation>Aj&amp;uda</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="137"/>
        <location filename="../../build/src/ui_main-win.h" line="794"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="141"/>
        <location filename="../../build/src/ui_main-win.h" line="795"/>
        <source>&amp;Sorting</source>
        <translation>&amp;Ordenação</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="166"/>
        <location filename="../../build/src/ui_main-win.h" line="796"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="184"/>
        <location filename="../../build/src/ui_main-win.h" line="797"/>
        <source>&amp;Bookmarks</source>
        <translation>&amp;Favoritos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="191"/>
        <location filename="../../build/src/ui_main-win.h" line="798"/>
        <source>&amp;Go</source>
        <translation>&amp;Ir</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="212"/>
        <location filename="../../build/src/ui_main-win.h" line="799"/>
        <source>&amp;Tool</source>
        <translation>Ferramen&amp;tas</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="229"/>
        <location filename="../../build/src/ui_main-win.h" line="800"/>
        <source>Main Toolbar</source>
        <translation>Barra de Ferramentas Principal</translation>
    </message>
</context>
<context>
    <name>MountOperationPasswordDialog</name>
    <message>
        <location filename="../mount-operation-password.ui" line="20"/>
        <location filename="../../build/src/ui_mount-operation-password.h" line="172"/>
        <source>Mount</source>
        <translation>Montar</translation>
    </message>
    <message>
        <location filename="../mount-operation-password.ui" line="48"/>
        <location filename="../../build/src/ui_mount-operation-password.h" line="174"/>
        <source>Connect &amp;anonymously</source>
        <translation>&amp;Conectar anonimamente</translation>
    </message>
    <message>
        <location filename="../mount-operation-password.ui" line="58"/>
        <location filename="../../build/src/ui_mount-operation-password.h" line="175"/>
        <source>Connect as u&amp;ser:</source>
        <translation>Conectar como u&amp;suário:</translation>
    </message>
    <message>
        <location filename="../mount-operation-password.ui" line="79"/>
        <location filename="../../build/src/ui_mount-operation-password.h" line="176"/>
        <source>&amp;Username:</source>
        <translation>&amp;Usuário:</translation>
    </message>
    <message>
        <location filename="../mount-operation-password.ui" line="102"/>
        <location filename="../../build/src/ui_mount-operation-password.h" line="177"/>
        <source>&amp;Password:</source>
        <translation>&amp;Senha:</translation>
    </message>
    <message>
        <location filename="../mount-operation-password.ui" line="112"/>
        <location filename="../../build/src/ui_mount-operation-password.h" line="178"/>
        <source>&amp;Domain:</source>
        <translation>&amp;Domínio:</translation>
    </message>
    <message>
        <location filename="../mount-operation-password.ui" line="127"/>
        <location filename="../../build/src/ui_mount-operation-password.h" line="179"/>
        <source>Forget password &amp;immediately</source>
        <translation>Esquecer senha &amp;imediatamente</translation>
    </message>
    <message>
        <location filename="../mount-operation-password.ui" line="137"/>
        <location filename="../../build/src/ui_mount-operation-password.h" line="180"/>
        <source>Remember password until you &amp;logout</source>
        <translation>Lembrar sen&amp;ha até encerrar a sessão</translation>
    </message>
    <message>
        <location filename="../mount-operation-password.ui" line="147"/>
        <location filename="../../build/src/ui_mount-operation-password.h" line="181"/>
        <source>Remember &amp;forever</source>
        <translation>Lembrar para s&amp;empre</translation>
    </message>
</context>
<context>
    <name>OverviewEffectConfig</name>
    <message>
        <location filename="../../kwin/src/plugins/overview/kcm/overvieweffectkcm.ui" line="22"/>
        <source>Ignore minimized windows:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/overview/kcm/overvieweffectkcm.ui" line="36"/>
        <source>Organize windows in the Grid View:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/overview/kcm/overvieweffectkcm.ui" line="50"/>
        <source>Search results include filtered windows:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../preferences.ui" line="14"/>
        <location filename="../../build/src/ui_preferences.h" line="616"/>
        <source>Preferences</source>
        <translation>Preferências</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="263"/>
        <location filename="../../build/src/ui_preferences.h" line="663"/>
        <source>User Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="35"/>
        <location filename="../../build/src/ui_preferences.h" line="626"/>
        <source>Behavior</source>
        <translation>Comportamento</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="419"/>
        <location filename="../preferences.ui" line="425"/>
        <location filename="../../build/src/ui_preferences.h" line="664"/>
        <location filename="../../build/src/ui_preferences.h" line="669"/>
        <source>Thumbnail</source>
        <translation>Miniaturas</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="479"/>
        <location filename="../../build/src/ui_preferences.h" line="679"/>
        <source>Advanced</source>
        <translation>Avançado</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="57"/>
        <location filename="../../build/src/ui_preferences.h" line="619"/>
        <source>Save metadata to directories (.DirInfo files)</source>
        <translation>Salvar metadados em pastas (arquivos .DirInfo)</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="67"/>
        <location filename="../../build/src/ui_preferences.h" line="620"/>
        <source>Spatial mode (folders open in a new window)</source>
        <translation>Modo espacial (as pastas abrem em uma nova janela)</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="134"/>
        <location filename="../../build/src/ui_preferences.h" line="627"/>
        <source>Icons</source>
        <translation>Ícones</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="163"/>
        <location filename="../../build/src/ui_preferences.h" line="629"/>
        <source>Size of big icons:</source>
        <translation>Tamanho dos ícones grandes:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="173"/>
        <location filename="../../build/src/ui_preferences.h" line="630"/>
        <source>Size of small icons:</source>
        <translation>Tamanho dos ícones pequenos:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="183"/>
        <location filename="../../build/src/ui_preferences.h" line="631"/>
        <source>Size of thumbnails:</source>
        <translation>Tamanho das miniaturas:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="193"/>
        <location filename="../../build/src/ui_preferences.h" line="632"/>
        <source>Size of side pane icons:</source>
        <translation>Tamanho dos ícones no painel lateral:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="146"/>
        <location filename="../../build/src/ui_preferences.h" line="628"/>
        <source>Icon theme:</source>
        <translation>Tema de ícones:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="269"/>
        <location filename="../../build/src/ui_preferences.h" line="639"/>
        <source>Window</source>
        <translation>Janela</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="278"/>
        <location filename="../../build/src/ui_preferences.h" line="640"/>
        <source>Remember the size of the last closed window</source>
        <translation>Lembrar tamanho da última janela fechada</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="285"/>
        <location filename="../../build/src/ui_preferences.h" line="641"/>
        <source>Default width of new windows:</source>
        <translation>Largura padrão das novas janelas:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="299"/>
        <location filename="../../build/src/ui_preferences.h" line="642"/>
        <source>Default height of new windows:</source>
        <translation>Altura padrão das novas janelas:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="41"/>
        <location filename="../../build/src/ui_preferences.h" line="617"/>
        <source>Browsing</source>
        <translation>Navegação</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="47"/>
        <location filename="../../build/src/ui_preferences.h" line="618"/>
        <source>Default view mode:</source>
        <translation>Modo de visualização:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="77"/>
        <location filename="../../build/src/ui_preferences.h" line="621"/>
        <source>File Operations</source>
        <translation>Operações de Arquivos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="83"/>
        <location filename="../../build/src/ui_preferences.h" line="622"/>
        <source>Confirm before deleting files</source>
        <translation>Confirmar antes de excluir arquivos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="455"/>
        <location filename="../../build/src/ui_preferences.h" line="668"/>
        <source>Show thumbnails of files</source>
        <translation>Mostrar miniaturas dos arquivos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="448"/>
        <location filename="../../build/src/ui_preferences.h" line="667"/>
        <source>Only show thumbnails for local files</source>
        <translation>Mostrar miniaturas apenas para arquivos locais</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="128"/>
        <location filename="../../build/src/ui_preferences.h" line="638"/>
        <source>Display</source>
        <translation>Tela</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="90"/>
        <location filename="../../build/src/ui_preferences.h" line="623"/>
        <source>Erase files on removable media instead of &quot;trash can&quot; creation</source>
        <translation>Apagar arquivos em dispositivos removíveis em vez de criar uma &quot;lixeira&quot;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="97"/>
        <location filename="../../build/src/ui_preferences.h" line="624"/>
        <source>Confirm before moving files into &quot;trash can&quot;</source>
        <translation>Confirmar antes de mover arquivos para a &quot;lixeira&quot;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="104"/>
        <location filename="../../build/src/ui_preferences.h" line="625"/>
        <source>Don&apos;t ask options on launch executable file</source>
        <translation>Não perguntar ao iniciar um arquivo executável</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="206"/>
        <location filename="../../build/src/ui_preferences.h" line="633"/>
        <source>User interface</source>
        <translation>Interface do usuário</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="219"/>
        <location filename="../../build/src/ui_preferences.h" line="635"/>
        <source>Treat backup files as hidden</source>
        <translation>Tratar arquivos de backup como ocultos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="229"/>
        <location filename="../../build/src/ui_preferences.h" line="636"/>
        <source>Always show full file names</source>
        <translation>Sempre mostrar os nomes completos dos arquivos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="239"/>
        <location filename="../../build/src/ui_preferences.h" line="637"/>
        <source>Show icons of hidden files shadowed</source>
        <translation>Mostrar ícones de arquivos ocultos sombreados</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="316"/>
        <location filename="../../build/src/ui_preferences.h" line="643"/>
        <source>Show in places</source>
        <translation>Mostrar em locais</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="323"/>
        <location filename="../../build/src/ui_preferences.h" line="648"/>
        <source>Home</source>
        <translation>Pasta pessoal</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="335"/>
        <location filename="../../build/src/ui_preferences.h" line="650"/>
        <source>Desktop</source>
        <translation>Área de trabalho</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="347"/>
        <location filename="../../build/src/ui_preferences.h" line="652"/>
        <source>Trash can</source>
        <translation>Lixeira</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="359"/>
        <location filename="../../build/src/ui_preferences.h" line="654"/>
        <source>Computer</source>
        <translation>Computador</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="371"/>
        <location filename="../../build/src/ui_preferences.h" line="656"/>
        <source>Applications</source>
        <translation>Aplicativos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="379"/>
        <location filename="../../build/src/ui_preferences.h" line="658"/>
        <source>Devices</source>
        <translation>Dispositivos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="387"/>
        <location filename="../../build/src/ui_preferences.h" line="660"/>
        <source>Network</source>
        <translation>Rede</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="431"/>
        <location filename="../../build/src/ui_preferences.h" line="665"/>
        <source>Do not generate thumbnails for image files exceeding this size:</source>
        <translation>Não gerar miniaturas para imagens maiores que:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="438"/>
        <location filename="../../build/src/ui_preferences.h" line="666"/>
        <source> KB</source>
        <translation> KB</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="579"/>
        <location filename="../../build/src/ui_preferences.h" line="687"/>
        <source>Mount</source>
        <translation type="unfinished">Montar</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="585"/>
        <location filename="../../build/src/ui_preferences.h" line="680"/>
        <source>Auto Mount</source>
        <translation>Montar Automaticamente</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="591"/>
        <location filename="../../build/src/ui_preferences.h" line="681"/>
        <source>Mount mountable volumes automatically on program startup</source>
        <translation>Montar discos removíveis ao iniciar o aplicativo</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="598"/>
        <location filename="../../build/src/ui_preferences.h" line="682"/>
        <source>Mount removable media automatically when they are inserted</source>
        <translation>Montar discos removíveis automaticamente quando são inseridos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="605"/>
        <location filename="../../build/src/ui_preferences.h" line="683"/>
        <source>Show available options for removable media when they are inserted</source>
        <translation>Mostrar opções para os discos assim que forem inseridos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="615"/>
        <location filename="../../build/src/ui_preferences.h" line="684"/>
        <source>When removable medium unmounted:</source>
        <translation>Ao desmontar um disco removível:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="621"/>
        <location filename="../../build/src/ui_preferences.h" line="685"/>
        <source>Close &amp;tab containing removable medium</source>
        <translation>Fechar aba con&amp;tendo mídia removível</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="628"/>
        <location filename="../../build/src/ui_preferences.h" line="686"/>
        <source>Chan&amp;ge folder in the tab to home folder</source>
        <translation>Alterar &amp;pasta da aba para pasta pessoal</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="485"/>
        <location filename="../../build/src/ui_preferences.h" line="670"/>
        <source>Programs</source>
        <translation>Programas</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="494"/>
        <location filename="../../build/src/ui_preferences.h" line="671"/>
        <source>Terminal emulator:</source>
        <translation>Emulador de terminal:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="501"/>
        <location filename="../../build/src/ui_preferences.h" line="672"/>
        <source>Switch &amp;user command:</source>
        <translation>Comando para trocar de &amp;usuário:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="511"/>
        <location filename="../../build/src/ui_preferences.h" line="673"/>
        <source>Examples: &quot;xterm -e %s&quot; for terminal or &quot;gksu %s&quot; for switching user.
%s = the command line you want to execute with terminal or su.</source>
        <translation>Exemplos: &quot;xterm -e %s&quot; para terminal ou &quot;gksu %s&quot; para trocar de usuário.
%s = a linha de comando para executar no terminal ou com o comando su.</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="532"/>
        <location filename="../../build/src/ui_preferences.h" line="675"/>
        <source>Templates</source>
        <translation>Modelos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="538"/>
        <location filename="../../build/src/ui_preferences.h" line="676"/>
        <source>Show only user defined templates in menu</source>
        <translation>Mostrar apenas modelos definidos pelo usuário no menu</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="545"/>
        <location filename="../../build/src/ui_preferences.h" line="677"/>
        <source>Show only one template for each MIME type</source>
        <translation>Mostrar apenas um modelo para cada tipo MIME</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="552"/>
        <location filename="../../build/src/ui_preferences.h" line="678"/>
        <source>Run default application after creation from template</source>
        <translation>Executar aplicativo padrão ao criar um modelo</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="212"/>
        <location filename="../../build/src/ui_preferences.h" line="634"/>
        <source>Use SI decimal prefixes instead of IEC binary prefixes</source>
        <translation>Utilizar prefixos decimais SI em vez dos prefixos binários IEC</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../utilities.cpp" line="128"/>
        <source>Please enter a new name:</source>
        <translation>Por favor, insira um novo nome:</translation>
    </message>
    <message>
        <location filename="../filelauncher.cpp" line="130"/>
        <source>Extract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filelauncher.cpp" line="131"/>
        <source>Could not extract &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filelauncher.cpp" line="231"/>
        <source>Cannot Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filelauncher.cpp" line="232"/>
        <source>There is no application installed to open this document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filelauncher.cpp" line="235"/>
        <source>Cannot Open Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filelauncher.cpp" line="236"/>
        <source>This Application is meant for macOS, it will not work on pearOS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filelauncher.cpp" line="310"/>
        <location filename="../mountoperation.cpp" line="185"/>
        <location filename="../utilities.cpp" line="133"/>
        <location filename="../utilities.cpp" line="210"/>
        <location filename="../utilities.cpp" line="286"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../utilities.cpp" line="127"/>
        <source>Rename</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <location filename="../utilities.cpp" line="133"/>
        <source>The startvolume cannot be renamed.</source>
        <translation>Não é possível mudar o nome do volume inicial.</translation>
    </message>
    <message>
        <location filename="../utilities.cpp" line="222"/>
        <source>Create Folder</source>
        <translation>Criar Pasta</translation>
    </message>
    <message>
        <location filename="../utilities.cpp" line="223"/>
        <source>Create File</source>
        <translation>Criar Arquivo</translation>
    </message>
    <message>
        <location filename="../utilities.cpp" line="227"/>
        <source>Please enter a new file name:</source>
        <translation>Por favor, insira o nome do novo arquivo:</translation>
    </message>
    <message>
        <location filename="../utilities.cpp" line="228"/>
        <source>New text file</source>
        <translation>Novo arquivo de texto</translation>
    </message>
    <message>
        <location filename="../utilities.cpp" line="232"/>
        <source>Please enter a new folder name:</source>
        <translation>Por favor, insira o nome da nova pasta:</translation>
    </message>
    <message>
        <location filename="../utilities.cpp" line="233"/>
        <source>New folder</source>
        <translation>Nova pasta</translation>
    </message>
    <message>
        <location filename="../utilities.cpp" line="238"/>
        <source>Enter a name for the new %1:</source>
        <translation>Insira o nome do novo %1:</translation>
    </message>
</context>
<context>
    <name>QuickEffectConfig</name>
    <message>
        <location filename="../../kwin/examples/quick-effect/package/contents/ui/config.ui" line="17"/>
        <source>Background color:</source>
        <translation type="unfinished">Cor de fundo:</translation>
    </message>
</context>
<context>
    <name>RenameDialog</name>
    <message>
        <location filename="../rename-dialog.ui" line="14"/>
        <location filename="../../build/src/ui_rename-dialog.h" line="156"/>
        <source>Confirm to replace files</source>
        <translation>Confirmação de substituição</translation>
    </message>
    <message>
        <location filename="../rename-dialog.ui" line="35"/>
        <location filename="../../build/src/ui_rename-dialog.h" line="157"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;There is already a file with the same name in this location.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Do you want to replace the existing file?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Já existe um arquivo com o mesmo nome neste lugar.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Deseja substituir o arquivo existente?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../rename-dialog.ui" line="56"/>
        <location filename="../../build/src/ui_rename-dialog.h" line="158"/>
        <source>dest</source>
        <translation>destino</translation>
    </message>
    <message>
        <location filename="../rename-dialog.ui" line="63"/>
        <location filename="../../build/src/ui_rename-dialog.h" line="159"/>
        <source>with the following file?</source>
        <translation>pelo seguinte arquivo?</translation>
    </message>
    <message>
        <location filename="../rename-dialog.ui" line="76"/>
        <location filename="../../build/src/ui_rename-dialog.h" line="160"/>
        <source>src file info</source>
        <translation>informações do arquivo de origem</translation>
    </message>
    <message>
        <location filename="../rename-dialog.ui" line="89"/>
        <location filename="../../build/src/ui_rename-dialog.h" line="161"/>
        <source>dest file info</source>
        <translation>informações do arquivo de destino</translation>
    </message>
    <message>
        <location filename="../rename-dialog.ui" line="102"/>
        <location filename="../../build/src/ui_rename-dialog.h" line="162"/>
        <source>src</source>
        <translation>origem</translation>
    </message>
    <message>
        <location filename="../rename-dialog.ui" line="122"/>
        <location filename="../../build/src/ui_rename-dialog.h" line="163"/>
        <source>&amp;File name:</source>
        <translation>Nome de &amp;arquivo:</translation>
    </message>
    <message>
        <location filename="../rename-dialog.ui" line="137"/>
        <location filename="../../build/src/ui_rename-dialog.h" line="164"/>
        <source>Apply this option to all existing files</source>
        <translation>Aplicar opção a todos os arquivos existentes</translation>
    </message>
</context>
<context>
    <name>ScaleEffectConfig</name>
    <message>
        <location filename="../../kwin/src/plugins/scale/package/contents/ui/config.ui" line="17"/>
        <source>Duration:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/scale/package/contents/ui/config.ui" line="30"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/scale/package/contents/ui/config.ui" line="33"/>
        <source> milliseconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/scale/package/contents/ui/config.ui" line="46"/>
        <source>Window open scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/scale/package/contents/ui/config.ui" line="53"/>
        <source>Window close scale:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchDialog</name>
    <message>
        <location filename="../filesearch.ui" line="14"/>
        <location filename="../../build/src/ui_filesearch.h" line="398"/>
        <source>Search Files</source>
        <translation>Procurar Arquivos</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="29"/>
        <location filename="../../build/src/ui_filesearch.h" line="408"/>
        <source>Name/Location</source>
        <translation>Nome/Localização</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="35"/>
        <location filename="../../build/src/ui_filesearch.h" line="399"/>
        <source>File Name Patterns:</source>
        <translation>Padrões do Nome de Arquivo:</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="41"/>
        <location filename="../../build/src/ui_filesearch.h" line="400"/>
        <source>*</source>
        <translation>*</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="48"/>
        <location filename="../../build/src/ui_filesearch.h" line="401"/>
        <source>Case insensitive</source>
        <translation>Ignorar maiúsculas</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="55"/>
        <location filename="../../build/src/ui_filesearch.h" line="402"/>
        <source>Use regular expression</source>
        <translation>Usar expressões regulares</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="65"/>
        <location filename="../../build/src/ui_filesearch.h" line="403"/>
        <source>Places to Search:</source>
        <translation>Lugares para Procurar:</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="78"/>
        <location filename="../../build/src/ui_filesearch.h" line="404"/>
        <source>&amp;Add</source>
        <translation>&amp;Adicionar</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="90"/>
        <location filename="../../build/src/ui_filesearch.h" line="405"/>
        <source>&amp;Remove</source>
        <translation>&amp;Remover</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="119"/>
        <location filename="../../build/src/ui_filesearch.h" line="406"/>
        <source>Search in sub directories</source>
        <translation>Procurar em subpastas</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="126"/>
        <location filename="../../build/src/ui_filesearch.h" line="407"/>
        <source>Search for hidden files</source>
        <translation>Procurar arquivos ocultos</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="137"/>
        <location filename="../../build/src/ui_filesearch.h" line="416"/>
        <source>File Type</source>
        <translation>Tipo de Arquivo</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="143"/>
        <location filename="../../build/src/ui_filesearch.h" line="409"/>
        <source>Only search for files of following types:</source>
        <translation>Pesquisar somente por arquivos dos seguintes tipos:</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="149"/>
        <location filename="../../build/src/ui_filesearch.h" line="410"/>
        <source>Text files</source>
        <translation>Arquivos de texto</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="156"/>
        <location filename="../../build/src/ui_filesearch.h" line="411"/>
        <source>Image files</source>
        <translation>Arquivos de imagem</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="163"/>
        <location filename="../../build/src/ui_filesearch.h" line="412"/>
        <source>Audio files</source>
        <translation>Arquivos de áudio</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="170"/>
        <location filename="../../build/src/ui_filesearch.h" line="413"/>
        <source>Video files</source>
        <translation>Arquivos de vídeo</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="177"/>
        <location filename="../../build/src/ui_filesearch.h" line="414"/>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="184"/>
        <location filename="../../build/src/ui_filesearch.h" line="415"/>
        <source>Folders</source>
        <translation>Pastas</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="208"/>
        <location filename="../../build/src/ui_filesearch.h" line="420"/>
        <source>Content</source>
        <translation>Conteúdo</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="214"/>
        <location filename="../../build/src/ui_filesearch.h" line="417"/>
        <source>File contains:</source>
        <translation>O arquivo contém:</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="223"/>
        <location filename="../../build/src/ui_filesearch.h" line="418"/>
        <source>Case insensiti&amp;ve</source>
        <translation>Diferenciar maiúsculas</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="230"/>
        <location filename="../../build/src/ui_filesearch.h" line="419"/>
        <source>&amp;Use regular expression</source>
        <translation>&amp;Usar expressões regulares</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="254"/>
        <location filename="../../build/src/ui_filesearch.h" line="437"/>
        <source>Properties</source>
        <translation>Propiedades</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="260"/>
        <location filename="../../build/src/ui_filesearch.h" line="421"/>
        <source>File Size:</source>
        <translation>Tamanho do Arquivo:</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="266"/>
        <location filename="../../build/src/ui_filesearch.h" line="422"/>
        <source>Larger than:</source>
        <translation>Maior que:</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="282"/>
        <location filename="../filesearch.ui" line="323"/>
        <location filename="../../build/src/ui_filesearch.h" line="423"/>
        <location filename="../../build/src/ui_filesearch.h" line="429"/>
        <source>Bytes</source>
        <translation>Bytes</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="287"/>
        <location filename="../filesearch.ui" line="328"/>
        <location filename="../../build/src/ui_filesearch.h" line="424"/>
        <location filename="../../build/src/ui_filesearch.h" line="430"/>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="292"/>
        <location filename="../filesearch.ui" line="333"/>
        <location filename="../../build/src/ui_filesearch.h" line="425"/>
        <location filename="../../build/src/ui_filesearch.h" line="431"/>
        <source>MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="297"/>
        <location filename="../filesearch.ui" line="338"/>
        <location filename="../../build/src/ui_filesearch.h" line="426"/>
        <location filename="../../build/src/ui_filesearch.h" line="432"/>
        <source>GiB</source>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="307"/>
        <location filename="../../build/src/ui_filesearch.h" line="428"/>
        <source>Smaller than:</source>
        <translation>Menor que:</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="351"/>
        <location filename="../../build/src/ui_filesearch.h" line="434"/>
        <source>Last Modified Time:</source>
        <translation>Última data de Modificação:</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="357"/>
        <location filename="../../build/src/ui_filesearch.h" line="435"/>
        <source>Earlier than:</source>
        <translation>Antes de:</translation>
    </message>
    <message>
        <location filename="../filesearch.ui" line="364"/>
        <location filename="../../build/src/ui_filesearch.h" line="436"/>
        <source>Later than:</source>
        <translation>Depois de:</translation>
    </message>
</context>
<context>
    <name>ShortcutDialog</name>
    <message>
        <location filename="../../kwin/src/shortcutdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/shortcutdialog.ui" line="25"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SlideEffectConfig</name>
    <message>
        <location filename="../../kwin/src/plugins/slide/slide_config.ui" line="17"/>
        <source>Gap between desktops</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/slide/slide_config.ui" line="23"/>
        <source>Horizontal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/slide/slide_config.ui" line="46"/>
        <source>Vertical:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/slide/slide_config.ui" line="72"/>
        <source>Slide desktop background</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WindowViewEffectConfig</name>
    <message>
        <location filename="../../kwin/src/plugins/windowview/kcm/windowvieweffectkcm.ui" line="22"/>
        <source>Ignore &amp;minimized windows</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WobblyWindowsEffectConfigForm</name>
    <message>
        <location filename="../../kwin/src/plugins/wobblywindows/wobblywindows_config.ui" line="20"/>
        <source>Advanced</source>
        <translation type="unfinished">Avançado</translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/wobblywindows/wobblywindows_config.ui" line="26"/>
        <source>&amp;Stiffness:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/wobblywindows/wobblywindows_config.ui" line="68"/>
        <source>Dra&amp;g:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/wobblywindows/wobblywindows_config.ui" line="81"/>
        <source>&amp;Move factor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/wobblywindows/wobblywindows_config.ui" line="155"/>
        <source>Wo&amp;bble when moving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/wobblywindows/wobblywindows_config.ui" line="162"/>
        <source>Wobble when &amp;resizing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/wobblywindows/wobblywindows_config.ui" line="182"/>
        <source>Enable &amp;advanced mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/wobblywindows/wobblywindows_config.ui" line="192"/>
        <source>&amp;Wobbliness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/wobblywindows/wobblywindows_config.ui" line="201"/>
        <source>Less</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kwin/src/plugins/wobblywindows/wobblywindows_config.ui" line="224"/>
        <source>More</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
